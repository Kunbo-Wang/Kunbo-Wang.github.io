#C=sim.tr$C; p=sim.tr$p;
L <- function(N, n, C, p, lambda2)
{
  -sum(n*log(p)+(N-n)*log(1-p)) + lambda2*C
}

#Z=sim.tr$Z; w=sim.tr$w; 
prob <- function(Z, w, C)
{
  t(t(Z)*c(p0,rep(1, C-1)))%*%t(w)
}

Lnewfun <- function(x, N, n, C, Z, w, t1, lambda2)
{
  w[t1,] = exp(x-max(x))/sum(exp(x-max(x)))
  p = t(t(Z)*c(p0,rep(1, C-1)))%*%t(w)
  sum = L(N[,t1], n[,t1], C, p[,t1], lambda2)
  return(sum)
}