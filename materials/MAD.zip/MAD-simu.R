#Z = sim.tr$Z; w=sim.tr$w; C=sim.tr$C; p=sim.tr$p;
#pnow = prob(Z, w, C); L(N, n, C, pnow, lambda2)

###############################################
start.time = proc.time()
source("fun.R")
source("DataGene.R")
Data <- Data_Generation()
N = Data$N
n = Data$n
S <- 80 # THE NUMBER OF SNP (I.E. NUMBER OF ROWS OF Z)
NT <- 25 #THE NUMBER OF TISSUES
p0 <- 0.01
library(sfsmisc)
library(foreach)
library(doMC)
registerDoMC(6)
Nsimu=1000
lambda2 = 2
result<-foreach (seed=1:Nsimu)%dopar%
{
  set.seed(seed)
  print(seed)
  C=2; Z=matrix(c(rep(1, S), rbinom(S, 1, 0.5)),S,C); w = matrix(c(rgamma(NT*C,1,1)), NT,C);w = w/rowSums(w)
  for (i in 1:40){
  for (s in 1:S)
  {
    combina=digitsBase(1:2^(C-1)-1)
    Zposs = rbind(rep(1, 2^(C-1)),combina)
    p = w%*%(Zposs*c(p0,rep(1, C-1)))
    sum = -colSums(n[s,]*log(p))-colSums((N[s,]-n[s,])*log(1-p)) + lambda2*C
    id = which(sum==min(sum))
    Z[s,] = Zposs[,id]
  }
  
  for (t1 in 1:NT)
  {
    tcoeff = nlminb(c(-8,rep(2, C-1)),lower=-10, upper=10, Lnewfun, N=N, n=n, C=C, Z=Z, w=w, t1=t1, lambda2=lambda2)$par
    w[t1,] = exp(tcoeff-max(tcoeff))/sum(exp(tcoeff-max(tcoeff)))
  }
  
  s=sample(1:S, 1)
  pold = prob(Z,w,C)
  Lold = L(N, n, C, pold, lambda2)
  Znew = cbind(Z,rep(0,S))
  Znew[s, C+1] = 1
  wnew = cbind(w, rep(0, NT))
  for (t1 in 1:NT)
  {
    tcoeff = nlminb(c(-8,rep(2, C)),lower=-10, upper=10, Lnewfun, N=N, n=n, C=(C+1), Z=Znew, w=wnew, t1=t1, lambda2=lambda2)$par
    wnew[t1,] = exp(tcoeff-max(tcoeff))/sum(exp(tcoeff-max(tcoeff)))
  }
  pnew = prob(Znew,wnew,C+1)
  Lnew = L(N, n, C+1, pnew, lambda2)
  if (Lnew<Lold)
  {
    C = C + 1
    Z = Znew
    w = wnew
  } 
  }
 list(C, Z, w)  
}
save(result, file=paste("lambda",lambda2,".RData",sep=""))
proc.time()-start.time


