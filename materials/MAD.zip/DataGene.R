Data_Generation <- function()
{
  set.seed(79861)
S <- 80 # THE NUMBER OF SNP (I.E. NUMBER OF ROWS OF Z)
NT <- 25 #THE NUMBER OF TISSUES

#SIMULATION TRUTH
sim.tr <- NULL
sim.tr$C <- 5  #TRUE NUMBER OF CELL TYPES INCLUDING BACKGROUND
sim.tr$p0 <- 0.01

#LATENT BINARY MATRXI, S BY C
sim.tr$Z <- array(0, dim=c(S, sim.tr$C))
sim.tr$Z[,1] <- 1 #BACKGROUND
sim.tr$Z[1:10, 2] <- 1
sim.tr$Z[1:25, 3] <- 1
sim.tr$Z[1:40, 4] <- 1
sim.tr$Z[1:60, 5] <- 1

#THETA: T BY C MATRIX
sim.tr$theta <- array(NA, dim=c(NT, sim.tr$C))
a.vec <- c(0.01, 0.3, 0.5, 0.05, 0.25)*20

for(i.t in 1:NT)
{
    tmp <- sample(a.vec[-1], sim.tr$C-1)
    tmp <- c(a.vec[1], tmp)  #COLUMN 1 (BACKGROUND CELL TYPE GETS SMALL COUNTS)
    sim.tr$theta[i.t, ] <- rgamma(sim.tr$C, tmp, 1)
}


#W: T BY C MATRIX and P: S BY T MATRIX
sim.tr$w <- sim.tr$theta/rowSums(sim.tr$theta)
sim.tr$p <- matrix(0, S,NT)
sim.tr$p = t(t(sim.tr$Z)*c(sim.tr$p0,1,1,1,1))%*%t(sim.tr$w)


#GENERATE DATA
N <- array(50, dim=c(S, NT)) #NUMBER OF READS INDICATING MUTATIONS
n <- array(rbinom(S*NT, N, sim.tr$p), dim=c(S, NT)) #TOTAL NUMBER OF READS
  return(list(N=N, n=n,sim.tr = sim.tr))
}


