
method_index <- 1
rho_index <- 1
seed <- 1

library(mgcv)
library(MASS)
library(survival)
library(mc2d)
library(tmvtnorm) #for multivariate normal
library(mvtnorm)
library(MCMCpack) #for inverse whishart
library(metRology)
source("update_pos.R")  #store all posterior
source("data_generate.R")

method_candidates = c("normal", "t", "nonlinear")
method = method_candidates[method_index]

#global variable
Npat=500
H = 10
Ncov=3
lambda0 = 4
Phi = diag(0.1, 2)
lambda1 = 1 #prior for M
lambda2 = 1
rho1 = 0.75
nu = 3

set.seed(seed)
###simulate the covariates Z: three dimensions
Z = matrix(NA, Npat, 3)
Z[,1] = rbinom(Npat, 1, 0.5)
Z[,2] = rtrunc(rnorm, Npat, linf=2, lsup=7.5, mean = 4.5, sd = 1)
Z[,3] = rbinom(Npat, 1, 0.4)

###bivaraite normal
response_prog = rep(0, Npat)
response_death = rep(0, Npat)
censor_time = rep(0, Npat)
theta_0 = c(1.5, 0.6, 2) #progression
eta_0 = c(4, 0.3, 1) #death
full_data = data_generate(method)

id1 = which(Z[,1]==1)
id0 = which(Z[,1]==0)
N1 = length(id1)
N0 = length(id0)
cov = cbind(rep(1, Npat), Z[,-1])
cov1 = Z[id1,]
cov0 = cbind(rep(1, N0), Z[id0,-1])
covariance1=exp(-outer(cov1[,1],cov1[,1],'-')^2-outer(cov1[,2],cov1[,2],'-')^2-outer(cov1[,3],cov1[,3],'-')^2) + 0.01*diag(length(id1))
inv_covariance1 = solve(covariance1)
covariance0=exp(-outer(cov0[,1],cov0[,1],'-')^2-outer(cov0[,2],cov0[,2],'-')^2-outer(cov0[,3],cov0[,3],'-')^2) + 0.01*diag(length(id0))
inv_covariance0 = solve(covariance0)


Niter = 5000
burn.in = 2000
lag=10

load(paste("mcmc_",method,"_",seed,".RData",sep=""))

c1 = matrix(0, length(id1), Npat)
c0 = matrix(0, length(id0), Npat)
for (k in 1:Npat)
{
  covD = cov[k,]
  coeff1 = t(cov1)-covD
  c1[,k] = exp(-colSums(coeff1^2))
  coeff0 = t(cov0)-covD
  c0[,k] = exp(-colSums(coeff0^2))
}
var1 = 1.01-diag(t(c1)%*%inv_covariance1%*%c1)
var0 = 1.01-diag(t(c0)%*%inv_covariance0%*%c0)
partial_cov1 = t(c1)%*%inv_covariance1
partial_cov0 = t(c0)%*%inv_covariance0

u_range = seq(3,7,0.3)
nsave = (Niter-burn.in)/lag
hu = array(0, c(nsave, 2, length(u_range)))
for (u_index in 1:length(u_range))
{
  print(u_index)
  hu[,,u_index] = fbar_iter(mcmc0, mcmc1, u_range[u_index], rho_index)
}

Nsimu=1
u_range = seq(3,7,0.3)
ratio_interval=array(0, c(2, length(u_range), 3))
rho_range = c(0.2, 0.5, 0.8)
temp_hu = matrix(0, Nsimu,length(u_range))
temp_ratio_interval = array(0, c(Nsimu,2, length(u_range)))
simu_hu = array(0, c(3,3,length(u_range)))
simu_hu_interval = array(0, c(3,3,2,length(u_range)))
MSE = matrix(0, 3, Nsimu)
RMSE = rep(0, 3)
RMSE_sd = rep(0, 3)
id = which(rowSums(hu[,1,]==0)==0)
tmp = ifelse(hu[id,1,]<=0.1 & hu[id,2,]<=0.1, 1, hu[id,2,]/hu[id,1,])
for (j in 1:14)
{
    temp_hu[seed,j] = mean(tmp[,j])
    temp_ratio_interval[seed,,j] = quantile(tmp[,j], c(0.025, 0.975))
}
  MSE[rho_index, seed] = sqrt(  mean(  (temp_hu[seed,1:9] - apply(hu_truth[,1:9],2, mean))^2 ) )
  temp_hu[seed,] = apply(tmp, 2, mean)
  temp_ratio_interval[seed,,] = apply(tmp, 2, function(x) quantile(x, c(0.025, 0.975)))
RMSE[rho_index] = mean(MSE[rho_index,id_index])
RMSE_sd[rho_index] = sd(MSE[rho_index,id_index])
simu_hu[method_index, rho_index,] = apply(temp_hu[id_index,], 2, mean) 
simu_hu_interval[method_index, rho_index,1,] = apply(temp_ratio_interval[id_index,1,], 2, mean)
simu_hu_interval[method_index, rho_index,2,] = apply(temp_ratio_interval[id_index,2,], 2, mean)
