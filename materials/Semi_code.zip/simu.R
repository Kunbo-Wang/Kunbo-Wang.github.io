library(MASS)
library(survival)
library(mc2d)
library(tmvtnorm) #for multivariate normal
library(mvtnorm)
library(MCMCpack) #for inverse whishart
library(metRology)
library(mgcv)
source("update_pos.R")  #store all posterior
source("data_generate.R")

method_index <- 1 # set up which simulation model you want to generate the data. 1. normal; 2: t; 3: nonlinear
method_candidates = c("normal", "t", "nonlinear")
method = method_candidates[method_index]

#global variable
Npat=500 #the number of patients
H = 10  #the upper limit for stick breaking of DP. 
Ncov=3
lambda0 = 4
Phi = diag(0.1, 2)
lambda1 = 1 #prior for M
lambda2 = 1
rho1 = 0.75
nu = 3

seed_index <- 1
set.seed(seed_index)
###simulate the covariates Z: three dimensions
Z = matrix(NA, Npat, 3)
Z[,1] = rbinom(Npat, 1, 0.5)
Z[,2] = rtrunc(rnorm, Npat, linf=2, lsup=7.5, mean = 4.5, sd = 1)
Z[,3] = rbinom(Npat, 1, 0.4)

###bivaraite normal
response_prog = rep(0, Npat)
response_death = rep(0, Npat)
censor_time = rep(0, Npat)
theta_0 = c(1.5, 0.6, 2) #progression
eta_0 = c(4, 0.3, 1) #death
full_data = data_generate(method)
##delta=xi=1, we observe both progression time and death time
##delta=xi=0, we only have the censoring time C
##delta=1, xi=0, we observe progression time, but censored before observing death
##delta=0, xi=1, we observe death only, but neither progression nor death
########################################################################

Niter = 5000
burn.in = 2000
lag=10
niter = (Niter-burn.in)/lag

id1 = which(Z[,1]==1)
id0 = which(Z[,1]==0)
N1 = length(id1)
N0 = length(id0)
cov = cbind(rep(1, Npat), Z[,-1])
cov1 = Z[id1,]
cov0 = cbind(rep(1, N0), Z[id0,-1])
covariance1=exp(-outer(cov1[,1],cov1[,1],'-')^2-outer(cov1[,2],cov1[,2],'-')^2-outer(cov1[,3],cov1[,3],'-')^2) + 0.01*diag(length(id1))
inv_covariance1 = solve(covariance1)
covariance0=exp(-outer(cov0[,1],cov0[,1],'-')^2-outer(cov0[,2],cov0[,2],'-')^2-outer(cov0[,3],cov0[,3],'-')^2) + 0.01*diag(length(id0))
inv_covariance0 = solve(covariance0)

var1_betah = solve(t(cov1)%*%inv_covariance1%*%cov1+diag(Ncov))
var0_betah = solve(t(cov0)%*%inv_covariance0%*%cov0+diag(Ncov))

partial_cov0 = t(cov0)%*%inv_covariance0
partial_cov1 = t(cov1)%*%inv_covariance1

#prior for \Sigma
Phi1 = cov(full_data[id1,1:2])
Phi0 = cov(full_data[id0,1:2])


mcmc0 <- NULL
mcmc0$M <- rep(NA, Niter)
mcmc0$Sigma <- array(NA, c(2,2, Niter))
mcmc0$muh <- array(NA, c(H, 2, N0, Niter))
mcmc0$betah1 <- array(NA, c(H, Ncov, Niter))
mcmc0$betah2 <- array(NA, c(H, Ncov, Niter))
mcmc0$r <- array(NA, c(N0, Niter))
mcmc0$wh <- array(NA, c(H, Niter))
mcmc0$imputey <- array(NA, c(N0,2, Niter))

set.seed(1)
##Initialize 
initial <- init(full_data[id0,1:2], N0)
mcmc0$M[1] = initial$M
mcmc0$Sigma[,,1] = initial$Sigma
for (i in 1:N0) mcmc0$muh[,,i,1] = initial$mh
mcmc0$wh[,1] = initial$wh
mcmc0$r[,1] = initial$r
lfit1 = survreg(Surv(full_data[id0,1],full_data[id0,3])~cov0,dist="gaussian")
lfit2 = survreg(Surv(full_data[id0,2],full_data[id0,4])~cov0,dist="gaussian")
mcmc0$betah1[,,1] = matrix(rep(lfit1$coefficients[-2], H),H,Ncov, byrow=T)
mcmc0$betah2[,,1] = matrix(rep(lfit2$coefficients[-2], H),H,Ncov, byrow=T)
mcmc0$imputey[,,1] = full_data[id0,1:2]
prior_betah1 = mcmc0$betah1[1,,1]
prior_betah2 = mcmc0$betah2[1,,1]

for (iter in 2:Niter)
{
  tmp = update_r(mcmc0$Sigma[,,iter-1], mcmc0$muh[,,,iter-1],mcmc0$wh[,iter-1], full_data[id0,], mcmc0$r[,iter-1], N0)
  mcmc0$r[,iter] = tmp$r
  mcmc0$imputey[,,iter] = tmp$impute_y
  tmp2 = update_wh_and_M(mcmc0$r[,iter], mcmc0$M[iter-1])
  mcmc0$M[iter] = tmp2$M
  mcmc0$wh[,iter] = tmp2$wh
  mcmc0$muh[,,,iter] = update_muh(mcmc0$wh[,iter-1],mcmc0$r[,iter], mcmc0$Sigma[,,iter-1], mcmc0$muh[,,,iter-1], mcmc0$imputey[,,iter], mcmc0$betah1[,,iter-1],mcmc0$betah2[,,iter-1], N0, cov0,covariance0, inv_covariance0,partial_cov0)
  mcmc0$betah1[,,iter] = update_betah1(mcmc0$muh[,,,iter], mcmc0$r[,iter],prior_betah1,var0_betah,partial_cov0)
  mcmc0$betah2[,,iter] = update_betah2(mcmc0$muh[,,,iter], mcmc0$r[,iter],prior_betah2,var0_betah,partial_cov0)
  mcmc0$Sigma[,,iter] = update_Sigma(mcmc0$r[,iter], mcmc0$imputey[,,iter], mcmc0$muh[,,,iter], N0, Phi0)
}

mcmc1 <- NULL
mcmc1$M <- rep(NA, Niter)
mcmc1$Sigma <- array(NA, c(2,2,Niter))
mcmc1$muh <- array(NA, c(H, 2, N1, Niter))
mcmc1$betah1 <- array(NA, c(H, Ncov, Niter))
mcmc1$betah2 <- array(NA, c(H, Ncov, Niter))
mcmc1$r <- array(NA, c(N1, Niter))
mcmc1$wh <- array(NA, c(H, Niter))
mcmc1$imputey <- array(NA, c(N1,2, Niter))




set.seed(1)
##Initialize 
initial <- init(full_data[id1,1:2], N1)
mcmc1$M[1] = initial$M
mcmc1$Sigma[,,1] = initial$Sigma
for (i in 1:N1) mcmc1$muh[,,i,1] = initial$mh
mcmc1$wh[,1] = initial$wh
mcmc1$r[,1] = initial$r
lfit1 = survreg(Surv(full_data[id1,1],full_data[id1,3])~cov1,dist="gaussian")
lfit2 = survreg(Surv(full_data[id1,2],full_data[id1,4])~cov1,dist="gaussian")
mcmc1$betah1[,,1] = matrix(rep(lfit1$coefficients[-2], H),H,Ncov, byrow=T)
mcmc1$betah2[,,1] = matrix(rep(lfit2$coefficients[-2], H),H,Ncov, byrow=T)
mcmc1$imputey[,,1] = full_data[id1,1:2]
prior_betah1 = mcmc1$betah1[1,,1]
prior_betah2 = mcmc1$betah2[1,,1]

for (iter in 2:Niter)
{
  print(iter)
  tmp = update_r(mcmc1$Sigma[,,iter-1], mcmc1$muh[,,,iter-1],mcmc1$wh[,iter-1], full_data[id1,], mcmc1$r[,iter-1], N1)
  mcmc1$r[,iter] = tmp$r
  mcmc1$imputey[,,iter] = tmp$impute_y
  tmp2 = update_wh_and_M(mcmc1$r[,iter], mcmc1$M[iter-1])
  mcmc1$M[iter] = tmp2$M
  mcmc1$wh[,iter] = tmp2$wh
  mcmc1$muh[,,,iter] = update_muh(mcmc1$wh[,iter-1],mcmc1$r[,iter], mcmc1$Sigma[,,iter-1], mcmc1$muh[,,,iter-1], mcmc1$imputey[,,iter], mcmc1$betah1[,,iter-1],mcmc1$betah2[,,iter-1], N1, cov1,covariance1, inv_covariance1,partial_cov1)
  mcmc1$betah1[,,iter] = update_betah1(mcmc1$muh[,,,iter], mcmc1$r[,iter],prior_betah1,var1_betah,partial_cov1)
  mcmc1$betah2[,,iter] = update_betah2(mcmc1$muh[,,,iter], mcmc1$r[,iter],prior_betah2,var1_betah,partial_cov1)
  mcmc1$Sigma[,,iter] = update_Sigma(mcmc1$r[,iter], mcmc1$imputey[,,iter], mcmc1$muh[,,,iter], N1, Phi1)
}
#save(mcmc0, mcmc1, file=paste("mcmc_", method,"_", seed_index, ".RData", sep=""))

##############Marginal for treatment 0
tim = seq(0,10,0.3)
fmean1 = matrix(0, length(tim), length(id0))
fmean2 = matrix(0, length(tim), length(id0))
fquantile1 = array(0, c(2, length(tim), length(id0)))
fquantile2 = array(0, c(2, length(tim), length(id0)))
fquantile1_ave = matrix(0, 2, length(tim))
fquantile2_ave = matrix(0, 2, length(tim))
for (k in 1:length(id0)){
  covD = cov0[k,]
  fgrid1 = NULL
  fgrid2 = NULL
  for (i in 1:niter)
  {
    iter = burn.in + i*lag
    FNP1 <- 1-fmar_survival(tim, mcmc0$wh[,iter],mcmc0$muh[,1,,iter], mcmc0$betah1[,,iter], mcmc0$Sigma[1,1,iter], covD, cov0, inv_covariance0)
    FNP2 <- 1-fmar_survival(tim, mcmc0$wh[,iter],mcmc0$muh[,2,,iter], mcmc0$betah2[,,iter], mcmc0$Sigma[2,2,iter], covD, cov0, inv_covariance0)
    fgrid1 <-rbind(fgrid1,FNP1)
    fgrid2 <-rbind(fgrid2,FNP2)
  }
  fmean1[,k] <- apply(fgrid1,2,mean)
  fmean2[,k] <- apply(fgrid2,2,mean)
  fquantile1[,,k] <- apply(fgrid1, 2, function(x) quantile(x,c(0.025,0.975)))
  fquantile2[,,k] <- apply(fgrid2, 2, function(x) quantile(x,c(0.025,0.975)))
}

fmean1_ave = apply(fmean1,1,mean)
fmean2_ave = apply(fmean2,1,mean)
fquantile1_ave[1,] = apply(fquantile1[1,,], 1, mean)
fquantile1_ave[2,] = apply(fquantile1[2,,], 1, mean)
fquantile2_ave[1,] = apply(fquantile2[1,,], 1, mean)
fquantile2_ave[2,] = apply(fquantile2[2,,], 1, mean)


fmean1_truth = matrix(0, length(tim), length(id0))
fmean2_truth = matrix(0, length(tim), length(id0))
for (k in 1:length(id0))
{
  covD = cov0[k,]
  if (method=="nonlinear")
  {
    fmean1_truth[,k] <- 1 - pnorm(tim, sum((theta_0 * covD)[-1]), 1)
    fmean2_truth[,k] <- 1 - pnorm(tim, sum((eta_0 * covD)[-1]) + 0.5*sqrt(covD[2]) + 1.5, 1)
  } else if (method %in% c("normal","dependent"))
  {
    fmean1_truth[,k] <- 1 - pnorm(tim, sum((theta_0 * covD)[-1]), 1)
    fmean2_truth[,k] <- 1 - pnorm(tim, sum((eta_0 * covD)[-1]) + 1.5, 1)
  } else
  {
    fmean1_truth[,k] <- 1 - pt.scaled(tim, df=3, sum((theta_0 * covD)[-1]), 1)
    fmean2_truth[,k] <- 1 - pt.scaled(tim, df=3, sum((eta_0 * covD)[-1]) + 1.5, 1)
  }
}
fmean1_truth_ave = apply(fmean1_truth,1,mean)
fmean2_truth_ave = apply(fmean2_truth,1,mean)

marginal0 = NULL
marginal0$fmean1_ave = fmean1_ave  
marginal0$fmean2_ave = fmean2_ave 
marginal0$fmean1_truth_ave = fmean1_truth_ave
marginal0$fmean2_truth_ave = fmean2_truth_ave
marginal0$fquantile1_ave = fquantile1_ave
marginal0$fquantile2_ave = fquantile2_ave

####Marginal for treatment 1
load(paste("mcmc_", method,"_", seed_index, ".RData", sep=""))
tim = seq(0,10,0.3)
fmean1 = matrix(0, length(tim), length(id1))
fmean2 = matrix(0, length(tim), length(id1))
fquantile1 = array(0, c(2, length(tim), length(id1)))
fquantile2 = array(0, c(2, length(tim), length(id1)))
fquantile1_ave = matrix(0, 2, length(tim))
fquantile2_ave = matrix(0, 2, length(tim))
for (k in 1:length(id1)){
  covD = cov1[k,]
  fgrid1 = NULL
  fgrid2 = NULL
  for (i in 1:niter)
  {
    iter = burn.in + i*lag
    FNP1 <- 1-fmar_survival(tim, mcmc1$wh[,iter],mcmc1$muh[,1,,iter], mcmc1$betah1[,,iter], mcmc1$Sigma[1,1,iter], covD, cov1, inv_covariance1)
    FNP2 <- 1-fmar_survival(tim, mcmc1$wh[,iter],mcmc1$muh[,2,,iter], mcmc1$betah2[,,iter], mcmc1$Sigma[2,2,iter], covD, cov1, inv_covariance1)
    fgrid1 <-rbind(fgrid1,FNP1)
    fgrid2 <-rbind(fgrid2,FNP2)
  }
  fmean1[,k] <- apply(fgrid1,2,mean)
  fmean2[,k] <- apply(fgrid2,2,mean)
  fquantile1[,,k] <- apply(fgrid1, 2, function(x) quantile(x,c(0.025,0.975)))
  fquantile2[,,k] <- apply(fgrid2, 2, function(x) quantile(x,c(0.025,0.975)))
}
fmean1_ave = apply(fmean1,1,mean)
fmean2_ave = apply(fmean2,1,mean)
fquantile1_ave[1,] = apply(fquantile1[1,,], 1, mean)
fquantile1_ave[2,] = apply(fquantile1[2,,], 1, mean)
fquantile2_ave[1,] = apply(fquantile2[1,,], 1, mean)
fquantile2_ave[2,] = apply(fquantile2[2,,], 1, mean)
fmean1_truth = matrix(0, length(tim), length(id1))
fmean2_truth = matrix(0, length(tim), length(id1))
for (k in 1:length(id1))
{
  covD = cov1[k,]
  if (method=="nonlinear")
  {
    fmean1_truth[,k] <- 1 - pnorm(tim, sum(theta_0 * covD), 1)
    fmean2_truth[,k] <- 1 - pnorm(tim, sum(eta_0 * covD) + 0.5*sqrt(covD[2]) + 1.5, 1)
  } else if (method %in% c("normal","dependent"))
  {
    fmean1_truth[,k] <- 1 - pnorm(tim, sum(theta_0 * covD) , 1)
    fmean2_truth[,k] <- 1 - pnorm(tim, sum(eta_0 * covD) + 1.5, 1)
  } else
  {
    fmean1_truth[,k] <- 1 - pt.scaled(tim, df=3, sum(theta_0 * covD), 1)
    fmean2_truth[,k] <- 1 - pt.scaled(tim, df=3, sum(eta_0 * covD) + 1.5, 1)
  }
}
fmean1_truth_ave = apply(fmean1_truth,1,mean)
fmean2_truth_ave = apply(fmean2_truth,1,mean)
marginal1 = NULL
marginal1$fmean1_ave = fmean1_ave  
marginal1$fmean2_ave = fmean2_ave 
marginal1$fmean1_truth_ave = fmean1_truth_ave
marginal1$fmean2_truth_ave = fmean2_truth_ave
marginal1$fquantile1_ave = fquantile1_ave
marginal1$fquantile2_ave = fquantile2_ave

##########################################################
