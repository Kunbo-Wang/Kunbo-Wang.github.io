data_generate <- function(method)
{
  data = matrix(NA, Npat, 4)
  if (method=="nonlinear")
  {
    response_prog = rep(0, Npat)
    response_death = rep(0, Npat)
    censor_time = rep(0, Npat)
    residule = rmvnorm(Npat, mean=c(0, 1.5), sigma = matrix(c(1,rho1,rho1, 1),2,2))
    response_prog = Z %*% theta_0 + residule[,1]
    response_death = Z %*% eta_0 + 0.5*sqrt(Z[,2]) + residule[,2]
    censor_time = runif(Npat, 8, 10)
    data = matrix(NA, Npat, 4)
    for (i in 1:Npat)
    {
      data[i,1] = min(response_prog[i], response_death[i], censor_time[i]) #X
      data[i,2] = min(response_death[i], censor_time[i]) #Y
      data[i,3] = (response_prog[i]<=min(response_death[i], censor_time[i])) #delta
      data[i,4] = (response_death[i]<=censor_time[i]) #epsilon
    }
  }
  if (method=="normal")
  {
    response_prog = rep(0, Npat)
    response_death = rep(0, Npat)
    censor_time = rep(0, Npat)
    residule = rmvnorm(Npat, mean=c(0, 0), sigma = matrix(c(1,rho1,rho1, 1),2,2))
    response_prog = Z %*% theta_0 + residule[,1]
    response_death = Z %*% eta_0 + 1.5 + residule[,2]
    censor_time = runif(Npat, 8, 10)
    data = matrix(NA, Npat, 4)
    for (i in 1:Npat)
    {
      data[i,1] = min(response_prog[i], response_death[i], censor_time[i]) #X
      data[i,2] = min(response_death[i], censor_time[i]) #Y
      data[i,3] = (response_prog[i]<=min(response_death[i], censor_time[i])) #delta
      data[i,4] = (response_death[i]<=censor_time[i]) #epsilon
    }
  }
  if (method=="t")
  {
    response_prog = rep(0, Npat)
    response_death = rep(0, Npat)
    censor_time = rep(0, Npat)
    response_death = rt.scaled(Npat, df=nu, mean = Z %*% eta_0 + 1.5, sd=1)
    response_prog = rt.scaled(Npat, df=nu+1, mean=Z%*%theta_0+rho1*(response_death - (Z %*% eta_0+1.5)), sqrt((1-rho1^2)*(nu+(response_death - (Z %*% eta_0+1.5))^2)/(nu+1) ) )
    #response_prog1 = rt.scaled(Npat, df=nu+1, mean=Z1%*%theta_0+rho1*(response_death1 - (Z1 %*% eta_0+2)), sqrt((1-rho1^2)*(nu+(response_death1 - (Z1 %*% eta_0+2))^2)/(nu+1) ) )
    censor_time = runif(Npat, 8, 10)
    data = matrix(NA, Npat, 4)
    for (i in 1:Npat)
    {
      data[i,1] = min(response_prog[i], response_death[i], censor_time[i]) #X
      data[i,2] = min(response_death[i], censor_time[i]) #Y
      data[i,3] = (response_prog[i]<=min(response_death[i], censor_time[i])) #delta
      data[i,4] = (response_death[i]<=censor_time[i]) #epsilon
    }
  }
  if (method=="dependent")
  {
    rho = exp(0.2*Z[,2]-Z[,3])/(1+exp(0.2*Z[,2]-Z[,3]))
    temp0 = matrix(0, Npat, 2)
    for (i in 1:Npat)
    {
      temp0[i,] = rmvnorm(1, mean=c(0, 0), sigma = matrix(c(1, rho[i], rho[i], 1), 2, 2))
    }
    #temp0 = rmvnorm(Npat, mean=c(0, 0), sigma = matrix(c(1, rho, rho, 1), 2, 2))
    temp1 = pnorm(temp0)
    response_death0 = qnorm(temp1[,1], mean = Z0 %*% eta_0+2, sd=1)
    response_death1 = qnorm(temp1[,2], mean = Z1 %*% eta_0+2, sd=1)
    response_prog0 = rnorm(Npat, Z0%*%theta_0+rho1*(response_death0 - (Z0 %*% eta_0+2)), sqrt(1-rho1^2))
    response_prog1 = rnorm(Npat, Z1%*%theta_0+rho1*(response_death1 - (Z1 %*% eta_0+2)), sqrt(1-rho1^2))
    id = which(Z[,1]==1)
    response_prog[id] = response_prog1[id]
    response_prog[-id] = response_prog0[-id]
    response_death[id] = response_death1[id]
    response_death[-id] = response_death0[-id]
    
    censor_time = log(runif(Npat, 6, 10))
    #censor_time = rep(200,Npat)
    data = matrix(NA, Npat, 4)
    for (i in 1:Npat)
    {
      data[i,1] = min(response_prog[i], response_death[i], censor_time[i]) #X
      data[i,2] = min(response_death[i], censor_time[i]) #Y
      data[i,3] = (response_prog[i]<=min(response_death[i], censor_time[i])) #delta
      data[i,4] = (response_death[i]<=censor_time[i]) #epsilon
    }
  }
  return(data)
}





