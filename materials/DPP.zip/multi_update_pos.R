#K=mcmc$K[iter-1]; mu=mcmc$mu[iter-1,1:mcmc$K[iter-1],]; w=mcmc$w[iter-1,1:mcmc$K[iter-1]];lambda=mcmc$lambda[iter-1,,]
update_zK <- function(K, mu, lambda, w)
{
  Sigma = update_Sigma(lambda, K)
  z = rep(0, Num)
  for (i in 1:Num)
  {
    den = rep(0, K)
    for (k in 1:K)
    {
      den[k] = w[k]*dmvnorm(y[i,], mu[k,], Sigma[,,k])
    }
    z[i] = sample(1:K, 1, prob = den)
  }
  exist_z = count(z)$x
  id = which(1:K%in%exist_z==0)
  if (length(id)>0)
  {
    mu = mu[-id,]
    w = w[-id]
    lambda = lambda[-id,]
  }
  Knew = length(count(z)$x)
  for (k in 1:Knew)
  {
    z[z==count(z)$x[k]] = k
  }
  return(list(z=z,K=Knew, mu=mu, w=w, lambda = lambda))
}

update_Sigma <- function(lambda, K)
{
  Sigma <- array(0, c(D,D,K))
  for (k in 1:K)
  {
    Sigma[,,k] <- Eigenvector%*%diag(lambda[k,])%*%t(Eigenvector)
  }
  return(Sigma)
}

#K=mcmc$K[iter]; z=mcmc$z[iter,]
update_w <- function(K, z)
{
  nlength = as.numeric(table(z))
  w = rdirichlet(1, hyper$delta+nlength)
  return(w)
}

#K=mcmc$K[iter]; mu=mcmc$mu[iter,1:mcmc$K[iter],];z=mcmc$z[iter,];
update_lambda <- function(mu, K, z)
{
  lambda = matrix(0, K, D)
  for (k in 1:K)
  {
    Sm = matrix(0, D, D)
    id = which(z==k)
    for (i in 1:length(id))
    {
      Sm = Sm + (y[id[i],]-mu[k,])%*%t(y[id[i],]-mu[k,])
    }
    lambda[k,] = 1/(rgamma(D,(length(id)+hyper$r+1)/2, (hyper$l+diag(t(Eigenvector)%*%Sm%*%Eigenvector))/2))
  }
  return(lambda)
}

cov_matrix <- function(mu, K)
{
  c = matrix(0, K, K)
  for (i in 1:K)
  {
    for (j in 1:K)
      c[i,j] = exp(-sum((mu[i,]-mu[j,])^2/hyper$theta))
  }
  return(c)
}

#mu = mcmc$mu[iter,1:mcmc$K[iter],]; z=mcmc$z[iter,]; K=mcmc$K[iter];Sigma = mcmc$Sigma[iter,,];theta = mcmc$theta[iter-1,];tau = mcmc$tau[iter-1,];
update_mu <- function(K, mu, z, lambda)
{
  Sigma = update_Sigma(lambda, K)
  for (k in 1:K)
  {
    covm =  cov_matrix(mu, K)
    invc = solve(covm[-k,-k])
    muold = mu[k,]
    munew = rmvnorm(1, mu[k,], hyper$sigmapro^2*diag(D))
    fnew = exp(-rowSums(t(t((matrix(1,K-1,1)%*%munew-mu[-k,])^2)/hyper$theta^2)))
    tmp1 = y[z==k,]-t(matrix(rep(munew,sum(z==k)),D,sum(z==k)))
    tmp2 = y[z==k,]-t(matrix(rep(muold,sum(z==k)),D,sum(z==k)))
    num = diag(tmp1%*%solve(Sigma[,,k])%*%t(tmp1))
    den = diag(tmp2%*%solve(Sigma[,,k])%*%t(tmp2))
    ratio = (1-fnew%*%invc%*%fnew)/(1-covm[k,-k]%*%invc%*%covm[k,-k])*exp( 0.5*sum(den) - 0.5*sum(num) ) 
    if (runif(1)<ratio) mu[k,] = munew
  }
  return(mu)
}

# #K=mcmc$K[iter]; mu=mcmc$mu[iter,1:mcmc$K[iter],];w= mcmc$w[iter,1:mcmc$K[iter]];z=mcmc$z[iter,];lambda=mcmc$lambda[iter,1:mcmc$K[iter],] 
# update_rj <- function(K,lambda, mu, w, z)
# {
#   Sigma = update_Sigma(lambda, K)
#   covold = cov_matrix(mu, K)
#   temp = rep(0, Num)
#   for (i in 1:Num)
#   {
#     temp[i] = dmvnorm(y[i,],mu[z[i],],Sigma[,,z[i]])
#   }
#   Likelihood_old = sum(log(temp))
#   
#   tmp0 = runif(1)
#   if (tmp0 < 0.5)
#   {
#     Knew = K+1
#     alpha <- rbeta(1,1,1) #alpha=0.5
#     beta <- rbeta(D, 1,1) #beta=c(0.5,0.5)
#     u <- rbeta(D, 2, 2)  #u=c(sqrt(0.5),sqrt(14/15))
#     u <- u * sample(c(-1,1),D,replace=TRUE)
#     id <- sample(1:K, 1)  #id=1
#     znew <- z
#     for (i in 1:Num)
#     {
#       if (z[i]<=id) znew[i] = z[i]
#       if (z[i]>id) znew[i] = z[i]-1
#     }
#     id_label <- which(z==id)
#     nid <- length(id_label)
#     w1 <- w[id]*alpha
#     w2 <- w[id]*(1-alpha)
#     wnew <- c(w[-id], w1, w2)
#     temp1 <- (sqrt(lambda[id,])*u)%*%t(Eigenvector)
#     mu1 <- mu[id,]-sqrt((1-alpha)/alpha)*temp1
#     mu2 <- mu[id,]+sqrt(alpha/(1-alpha))*temp1
#     munew <- rbind(mu[-id,], mu1, mu2)
#     covnew = cov_matrix(munew, Knew)
#     lambda1 = beta*(1-u^2)/alpha*lambda[id,]
#     lambda2 = (1-beta)*(1-u^2)*lambda[id,]/(1-alpha)
#     lambdanew = rbind(lambda[-id,], lambda1, lambda2)
#     Sigmanew = update_Sigma(lambdanew, Knew)
#     p1 <- w1 * dmvnorm(y[id_label,], mu1, Sigmanew[,,Knew-1])
#     p2 <- w2 * dmvnorm(y[id_label,], mu2, Sigmanew[,,Knew])
#     prob <- ifelse((p1+p2==0), 0, p1/(p1+p2))
#     tmp2 <- rbern(nid,prob)
#     znew[id_label[which(tmp2==1)]] = Knew-1
#     znew[id_label[which(tmp2==0)]] = Knew
#     n1 <- sum(tmp2)
#     n2 <- nid - n1
#     tempnew = rep(0, Num)
#     for (i in 1:Num)
#    {
#       tempnew[i] = dmvnorm(y[i,],munew[znew[i],],Sigmanew[,,znew[i]])
#     }
#     Likelihood_new = sum(log(tempnew))
#     ratio_like <- Likelihood_new - Likelihood_old
#     ratio_prior <- -log(Knew) + (hyper$delta-1+n1)*log(w1) + (hyper$delta-1+n2)*log(w2) - (hyper$delta-1+nid)*log(w[id]) - log(beta(hyper$delta, K*hyper$delta)) + log(det(covnew)) - log(det(covold)) + sum(log(lambda1*lambda2/lambda[id,]*(hyper$l/lambda1/2)^(2)*(hyper$l/lambda2/2)^(2)/(hyper$l/lambda[id,]/2)^(2) ) ) - 0.5*sum(4/lambda1+4/lambda2-4/lambda[id,])
#     ratio_propose <- log(dbeta(alpha,1,1)) + sum(log(dbeta(beta,1,1))) + sum(log(dbeta(abs(u),2,2)))
#     Jacobian <- (3*D+1)*log(w[id]) - 1.5*D*log(w1*w2) + sum(log(lambda[id,]^1.5*(1-u^2)))
#     birth_ratio <- exp(ratio_like + ratio_prior - ratio_propose + Jacobian) 
#     if (runif(1)<birth_ratio)
#     {
#       K = Knew
#       w = wnew
#       mu = munew
#       lambda = lambdanew
#       z = znew
#     }
#   } else
#   {
#     Knew = K - 1
#     id <- sample(1:K, 2)  #id=1
#     id <- sort(id)
#     id1 <- id[1]
#     id2 <- id[2]
#     n1 <- sum(z==id1)
#     n2 <- sum(z==id2)
#     znew <- z
#     for (i in 1:Num)
#     {
#       if (z[i]<id1) znew[i] = z[i]
#       if (z[i]>id1 & z[i]<=id2) znew[i] = z[i]-1
#       if (z[i]>id2) znew[i] = z[i]-2
#       if (z[i]==id1 | z[i]==id2) znew[i] = Knew
#     }
#     w1 = w[id1] + w[id2]
#     wnew = c(w[-id],w1)
#     alpha <- w[id1]/w1
#     mu1 = (w[id1]*mu[id1,] + w[id2]*mu[id2,])/w1
#     munew <- rbind(mu[-id,], mu1)
#     covnew = cov_matrix(munew, Knew)
#     lambda1 = alpha*lambda[id1,] + (1-alpha)*lambda[id2,] + alpha*(1-alpha)*(mu[id1,]-mu[id2,])^2
#     u <- solve(t(sqrt(lambda1)*t(Eigenvector)), (mu1-mu[id1,])/sqrt(w[id2]/w[id1]))
#     u = abs(u)
#     tmp3 = lambda[id1,]/lambda[id2,]*alpha/(1-alpha)
#     beta = tmp3/(tmp3+1)
#     lambdanew = rbind(lambda[-id,],lambda1)
#     Sigmanew = update_Sigma(lambdanew, Knew)
#     covnew = cov_matrix(munew, Knew)
#     tempnew = rep(0, Num)
#     for (i in 1:Num)
#     {
#       tempnew[i] = dmvnorm(y[i,],munew[znew[i],],Sigmanew[,,znew[i]])
#     }
#     Likelihood_new = sum(log(tempnew))
#     ratio_like <- Likelihood_new - Likelihood_old
#     ratio_prior <- log(K) - (hyper$delta-1+n1)*log(w[id1]) - (hyper$delta-1+n2)*log(w[id2]) + (hyper$delta-1+n1+n2)*log(w1) + log(beta(hyper$delta, Knew*hyper$delta)) + log(det(covnew)) - log(det(covold)) - sum(log(lambda1/lambda[id1,]/lambda[id2,]*(hyper$l/lambda1/2)^(2)/(hyper$l/lambda[id1,]/2)^(2)/(hyper$l/lambda[id2,]/2)^(2) ) ) + 0.5*sum(4/lambda[id1,]+4/lambda[id2,]-4/lambda1)
#     ratio_propose <- log(dbeta(alpha,1,1)) + sum(log(dbeta(beta,1,1))) + sum(log(dbeta(abs(u),2,2)))
#     Jacobian <- -(3*D+1)*log(w1) + 1.5*D*log(w[id1]*w[id2]) - sum(log(abs(lambda[id,]^1.5*(1-u^2))))
#     death_ratio <- exp(ratio_like + ratio_prior + ratio_propose + Jacobian)
#     death_ratio
#     if (runif(1)<death_ratio)
#     {
#       K = Knew
#       w = wnew
#       mu = munew
#       lambda = lambdanew
#       z = znew
#     }
#   }
#   return(list(K=K, mu=mu, w=w, lambda=lambda, z=z))
# }





#K=mcmc$K[iter]; mu=mcmc$mu[iter,1:mcmc$K[iter],];w= mcmc$w[iter,1:mcmc$K[iter]];z=mcmc$z[iter,];lambda=mcmc$lambda[iter,1:mcmc$K[iter],] 
update_rj <- function(K,lambda, mu, w, z)
{
  Sigma = update_Sigma(lambda, K)
  covold = cov_matrix(mu, K)
  temp = rep(0, Num)
  for (i in 1:Num)
  {
    temp[i] = dmvnorm(y[i,],mu[z[i],],Sigma[,,z[i]])
  }
  Likelihood_old = sum(log(temp))
  
  tmp0 = runif(1)
  if (K==1 | tmp0 < 0.5)
  {
    Knew = K+1
    alpha <- rbeta(1,1,1) #alpha=0.5
    beta <- rbeta(D, 1,1) #beta=c(0.5,0.5)
    u <- rbeta(D, 2, 2)  #u=c(sqrt(0.5),sqrt(14/15))
    u <- u * sample(c(-1,1),D,replace=TRUE)
    id <- sample(1:K, 1)  #id=1
    znew <- z
    for (i in 1:Num)
    {
      if (z[i]<=id) znew[i] = z[i]
      if (z[i]>id) znew[i] = z[i]-1
    }
    id_label <- which(z==id)
    nid <- length(id_label)
    w1 <- w[id]*alpha
    w2 <- w[id]*(1-alpha)
    wnew <- c(w[-id], w1, w2)
    temp1 <- (sqrt(lambda[id,])*u)%*%t(Eigenvector)
    mu1 <- mu[id,]-sqrt((1-alpha)/alpha)*temp1
    mu2 <- mu[id,]+sqrt(alpha/(1-alpha))*temp1
    munew <- rbind(mu[-id,], mu1, mu2)
    covnew = cov_matrix(munew, Knew)
    lambda1 = beta*(1-u^2)/alpha*lambda[id,]
    lambda2 = (1-beta)*(1-u^2)*lambda[id,]/(1-alpha)
    lambdanew = rbind(lambda[-id,], lambda1, lambda2)
    Sigmanew = update_Sigma(lambdanew, Knew)
    p1 <- w1 * dmvnorm(y[id_label,], mu1, Sigmanew[,,Knew-1])
    p2 <- w2 * dmvnorm(y[id_label,], mu2, Sigmanew[,,Knew])
    prob <- ifelse((p1+p2==0), 0, p1/(p1+p2))
    tmp2 <- rbern(nid,prob)
    znew[id_label[which(tmp2==1)]] = Knew-1
    znew[id_label[which(tmp2==0)]] = Knew
    n1 <- sum(tmp2)
    n2 <- nid - n1
    tempnew = rep(0, Num)
    for (i in 1:Num)
    {
      tempnew[i] = dmvnorm(y[i,],munew[znew[i],],Sigmanew[,,znew[i]])
    }
    Likelihood_new = sum(log(tempnew))
    ratio_like <- Likelihood_new - Likelihood_old
    ratio_prior <- (hyper$delta-1+n1)*log(w1) + (hyper$delta-1+n2)*log(w2) - (hyper$delta-1+nid)*log(w[id]) - log(beta(hyper$delta, K*hyper$delta)) + log(det(covnew)) - log(det(covold)) + sum(log(lambda1*lambda2/lambda[id,]*(hyper$l/lambda1/2)^(2)*(hyper$l/lambda2/2)^(2)/(hyper$l/lambda[id,]/2)^(2) ) ) - 0.5*sum(4/lambda1+4/lambda2-4/lambda[id,])
    ratio_propose <- log(dbeta(alpha,1,1)) + sum(log(dbeta(beta,1,1))) + sum(log(dbeta(abs(u),2,2)))
    ratio_move <- -log(Knew)
    ratio_alloc <- -sum(log(prob[tmp2==1])) - sum(log(1-prob[tmp2==0]))
    Jacobian <- (3*D+1)*log(w[id]) - 1.5*D*log(w1*w2) + sum(log(lambda[id,]^1.5*(1-u^2)))
    birth_ratio <- exp(ratio_like + ratio_prior -log(Knew) + ratio_move + ratio_alloc - ratio_propose + Jacobian) 
    if (runif(1)<birth_ratio)
    {
      K = Knew
      w = wnew
      mu = munew
      lambda = lambdanew
      z = znew
    }
  } else
  {
    if (K==1) death_ratio = 0 else{
    Knew = K - 1
    id <- sample(1:K, 2)  #id=1
    id <- sort(id)
    id1 <- id[1]
    id2 <- id[2]
    n1 <- sum(z==id1)
    n2 <- sum(z==id2)
    znew <- z
    for (i in 1:Num)
    {
      if (z[i]<id1) znew[i] = z[i]
      if (z[i]>id1 & z[i]<=id2) znew[i] = z[i]-1
      if (z[i]>id2) znew[i] = z[i]-2
      if (z[i]==id1 | z[i]==id2) znew[i] = Knew
    }
    w1 = w[id1] + w[id2]
    p11 <- w[id1] * dmvnorm(y[z==id1,], mu[id1,], Sigma[,,id1])
    p12 <- w[id2] * dmvnorm(y[z==id1,], mu[id2,], Sigma[,,id2])
    p21 <- w[id1] * dmvnorm(y[z==id2,], mu[id1,], Sigma[,,id1])
    p22 <- w[id2] * dmvnorm(y[z==id2,], mu[id2,], Sigma[,,id2])
    prob1 <- ifelse((p11+p12==0), 0, p11/(p11+p12))
    prob2 <- ifelse((p21+p22==0), 0, p22/(p21+p22))
    wnew = c(w[-id],w1)
    alpha <- w[id1]/w1
    mu1 = (w[id1]*mu[id1,] + w[id2]*mu[id2,])/w1
    munew <- rbind(mu[-id,], mu1)
    covnew = cov_matrix(munew, Knew)
    lambda1 = alpha*lambda[id1,] + (1-alpha)*lambda[id2,] + alpha*(1-alpha)*(mu[id1,]-mu[id2,])^2
    u <- solve(t(sqrt(lambda1)*t(Eigenvector)), (mu1-mu[id1,])/sqrt(w[id2]/w[id1]))
    u = abs(u)
    tmp3 = lambda[id1,]/lambda[id2,]*alpha/(1-alpha)
    beta = tmp3/(tmp3+1)
    lambdanew = rbind(lambda[-id,],lambda1)
    Sigmanew = update_Sigma(lambdanew, Knew)
    covnew = cov_matrix(munew, Knew)
    tempnew = rep(0, Num)
    for (i in 1:Num)
    {
      tempnew[i] = dmvnorm(y[i,],munew[znew[i],],Sigmanew[,,znew[i]])
    }
    Likelihood_new = sum(log(tempnew))
    ratio_like <- Likelihood_new - Likelihood_old
    ratio_alloc <- sum(log(prob1)) + sum(log(prob2))
    ratio_move <- log(K)
    ratio_prior <- - (hyper$delta-1+n1)*log(w[id1]) - (hyper$delta-1+n2)*log(w[id2]) + (hyper$delta-1+n1+n2)*log(w1) + log(beta(hyper$delta, Knew*hyper$delta)) + log(det(covnew)) - log(det(covold)) - sum(log(lambda1/lambda[id1,]/lambda[id2,]*(hyper$l/lambda1/2)^(2)/(hyper$l/lambda[id1,]/2)^(2)/(hyper$l/lambda[id2,]/2)^(2) ) ) + 0.5*sum(4/lambda[id1,]+4/lambda[id2,]-4/lambda1)
    ratio_propose <- log(dbeta(alpha,1,1)) + sum(log(dbeta(beta,1,1))) + sum(log(dbeta(abs(u),2,2)))
    Jacobian <- -(3*D+1)*log(w1) + 1.5*D*log(w[id1]*w[id2]) - sum(log(abs(lambda[id,]^1.5*(1-u^2))))
    death_ratio <- exp(log(K) + ratio_move + ratio_alloc + ratio_like + ratio_prior + ratio_propose + Jacobian)
    }#death_ratio
    if (runif(1)<death_ratio)
    {
      K = Knew
      w = wnew
      mu = munew
      lambda = lambdanew
      z = znew
    }
  }
  return(list(K=K, mu=mu, w=w, lambda=lambda, z=z))
}