setwd("~/Research/Project/PeterMuller/DPP/clustering/code/multi-dimension")
library(MASS)
library(gtools)
library(plyr)
library(MCMCpack) #for riwish
library(mvtnorm)
library(mc2d)
require(mdp)
source("multi_update_pos.R")

#data = read.table("mRNA.txt")
load("exp.RData")

# for (i in 1:17)
# {
#   y = as.matrix(data[,c(i,i+1)])
#   par(ask=TRUE)
#   plot(y)
# }
# y = as.matrix(data)
# y = as.matrix(data[,c(21:22)])
# heatmap.2(exp, trace="none", Colv=TRUE, Rowv=TRUE, scale="column", col=redgreen)
# kmeans(y,3)
y = exp
D = dim(y)[2] #dimension
Num = dim(y)[1]

##################################################################
Smatrix <- matrix(0, D, D)
for (i in 1:Num)
{
  Smatrix <- Smatrix + y[i,]%*%t(y[i,])
}
Smatrix <- Smatrix/Num
Eigenvector <- eigen(Smatrix)$vectors
##hyperparameters###
hyper = NULL
hyper$r = 4
hyper$l = 4
hyper$delta = 1
hyper$sigmapro = 0.2
hyper$theta = 4


#start_time = proc.time()
Niter = 10000
burn.in = 5000
lag = 10
mcmc = NULL
mcmc$z = matrix(NA, Niter, Num)
mcmc$w = matrix(NA, Niter, Num)
mcmc$mu = array(NA, c(Niter, Num, D))
mcmc$K = rep(NA, Niter)
mcmc$lambda = array(0, c(Niter, Num, D))
###################################################################

##################################################################
##Initial values using K-means
set.seed(2)
mcmc$K[1] = 4
cl = kmeans(y, mcmc$K[1])
mcmc$z[1,] = cl$cluster
mcmc$w[1,1:mcmc$K[1]] = cl$size/sum(cl$size)
mcmc$mu[1,1:mcmc$K[1],] = cl$centers
mcmc$lambda[1,1:mcmc$K[1],] = matrix(2, mcmc$K[1], D)

###################################################################

###################################################################

for (iter in 2:Niter)
{
  print(iter)
  tmp = update_zK(mcmc$K[iter-1], mcmc$mu[iter-1,1:mcmc$K[iter-1],], mcmc$lambda[iter-1,1:mcmc$K[iter-1],], mcmc$w[iter-1,1:mcmc$K[iter-1]])
  mcmc$K[iter] = tmp$K
  mcmc$z[iter,] = tmp$z
  mcmc$mu[iter,1:mcmc$K[iter],] = tmp$mu
  mcmc$w[iter,1:mcmc$K[iter]] = tmp$w
  mcmc$lambda[iter,1:mcmc$K[iter],] = tmp$lambda
  mcmc$w[iter,1:mcmc$K[iter]] = update_w(mcmc$K[iter], mcmc$z[iter,])
  mcmc$lambda[iter,1:mcmc$K[iter],] = update_lambda(mcmc$mu[iter,1:mcmc$K[iter],],mcmc$K[iter],  mcmc$z[iter,])
  mcmc$mu[iter,1:mcmc$K[iter],] = update_mu(mcmc$K[iter], mcmc$mu[iter,1:mcmc$K[iter],], mcmc$z[iter,],mcmc$lambda[iter,1:mcmc$K[iter],])
  tmp2 = update_rj(mcmc$K[iter],mcmc$lambda[iter,1:mcmc$K[iter],], mcmc$mu[iter,1:mcmc$K[iter],], mcmc$w[iter,1:mcmc$K[iter]],mcmc$z[iter,])
  mcmc$K[iter] = tmp2$K
  mcmc$w[iter,1:mcmc$K[iter]] = tmp2$w
  mcmc$mu[iter,1:mcmc$K[iter],] = tmp2$mu
  mcmc$lambda[iter,1:mcmc$K[iter],] = tmp2$lambda
  mcmc$z[iter,] = tmp2$z
  print(mcmc$K[iter])
}
proc.time()-start_time
save(mcmc,file="real_multi_DPP.RData")
#hist(mcmc$K)
load("real_multi_DPP.RData")

cluster = cluster_eval(mcmc)
names(cluster) = rownames(exp)
result = cbind(rownames(exp),cluster)
write(t(result), file = "yanxun_cluster.txt",ncol=2)

##############DPM
a=mdp(Y=y,n.iter=5000,n.discard=2000,
      pxy=1,exy=1,ex=1,ix=1,iy=2,iz=3,
      s=20, q=20,cc=20, k0=1, n.batch=10)

n_DPM = read.table("par.mdp")
nclass_DPM = n_DPM[,4]
pdf("hist_real_DPM.pdf")
hist(nclass_DPM, main=NULL, xlab="ncluster",cex.axis=1.2, cex.lab=1.2)
dev.off()

a=matrix(scan("member.mdp"),244,299)
membership = a[-1,]
membership1 = membership + 1
Hmatrix = matrix(0, Num, Num)
tmp = array(0, c(Num, Num, 299))
for (i in 1:299)
{
  tmp1 = matrix(0,243, 243)
  for (j in 1:243)
  {
    for (k in 1:243)
    {
      tmp1[j,k] = (membership1[j,i]==membership1[k,i])
    }
  }
  tmp[,,i] = tmp1
  Hmatrix = Hmatrix + tmp[,,i]
}
Hmatrix_ave = Hmatrix/299
diff = rep(0, 299)
for (i in 1:299)
{
  diff[i] = sum((Hmatrix_ave-tmp[,,i])^2)
}
idmin = which(diff==min(diff))[1]
cluster = membership1[,idmin]
names(cluster) = rownames(exp)
result = cbind(rownames(exp),as.numeric(cluster))
write(t(result), file = "yanxun_cluster_DPM.txt",ncol=2)


