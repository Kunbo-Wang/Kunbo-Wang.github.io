cluster_eval <- function(mcmc)
{
  Hmatrix = matrix(0, Num, Num)
  tmp = array(0, c(Num, Num, 500))
  for (i in 1:500)
  {
    iter = burn.in + i*lag
    tmp1 = mcmc$z[iter,]%*%t(mcmc$z[iter,])
    id = which(tmp1==1 | tmp1==4 | tmp1==9)
    tmp1[id] = 1
    tmp1[-id] = 0
    tmp[,,i] = tmp1
    Hmatrix = Hmatrix + tmp[,,i]
  }
  Hmatrix_ave = Hmatrix/500
  diff = rep(0, 500)
  for (i in 1:500)
  {
    diff[i] = sum((Hmatrix_ave-tmp[,,i])^2)
  }
  idmin = which(diff==min(diff))[1]
  cluster = mcmc$z[burn.in + idmin*lag,]
  return(cluster)
}

tmp1 = cluster%*%t(cluster)
id = which(tmp1==1 | tmp1==4 | tmp1==9)
tmp1[id] = 1
tmp1[-id] = 0
truth_cluster = matrix(0, Num, Num)
truth_cluster[1:120,1:120] = 1
truth_cluster[121:200,121:200] = 1
truth_cluster[201:300,201:300] = 1
sum((truth_cluster-tmp1)^2)
#3798

answ = rep(0, 300)
for (i in 1:300) {
kmeans_cluster = kmeans(y, 3)$cluster
tmp2 = kmeans_cluster%*%t(kmeans_cluster)
id = which(tmp2==1 | tmp2==4 | tmp2==9)
tmp2[id] = 1
tmp2[-id] = 0
answ[i] = sum((truth_cluster-tmp2)^2)
}
mean(answ)
#4217.2
