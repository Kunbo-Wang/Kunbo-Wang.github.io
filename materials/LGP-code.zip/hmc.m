%theta=theta1(s-1,:);input=train;a=a1(:,:,s);g=g1(:,:,s);
%theta=theta2(s-1,:);input=train;a=a2(:,:,s);
%HMC Hybrid Monte Carlo sampling
function theta=hmc(theta, input, a, g, thetaprior)

%nsamples=100;%the number of samples
L=10;%steps in leapfrog
step_size=0.01;%defaul
nparams=length(theta);

p=randn(1,nparams);%initial momenta at random
Eold=energy_pos(theta, input, a,g, thetaprior);


%main loop
%while n<=nsamples
    thetaold=theta; %store starting position
    pold=p; %store starting momenta
    Hold=Eold+0.5*(p*p');%recalculate Hamiltonian as momenta have changed
    
 %Choose a direction at random
   % if (rand < 0.5)
   %   lambda = -1;
   % else
      lambda = 1;
   %end
% step length.
  %epsilon = 0.5*50^(-1/2);
 epsilon =lambda*step_size;

  % First half-step of leapfrog.
  p = p - 0.5*epsilon*gradient(theta, input, a, g, thetaprior);
  theta = theta + epsilon*p;
  
  
  % Full leapfrog steps.
  for l = 1 : L - 1
    p = p - epsilon*gradient(theta, input, a, g, thetaprior);
    theta = theta + epsilon*p;
  end

  % Final half-step of leapfrog.
  p = p - 0.5*epsilon*gradient(theta, input, a, g, thetaprior);
  
  % Now apply Metropolis algorithm.
  Enew = energy_pos(theta, input, a, g, thetaprior);	% Evaluate new energy.
  Hnew = Enew + 0.5*p*p';		% Evaluate new Hamiltonian.
  b = exp(Hold - Hnew);			% Acceptance threshold.
  
  
   if b > rand(1)			% Accept the new state.
    Eold = Enew;			% Update energy
   else
       theta=thetaold;
       p=-pold;
   end
   
   %set momenta for next iteration
  %p=0.95*p+sqrt(1-0.95^2)*randn(1,nparams);
  %n=n+1;
end



  
  
  
  
  
  
  
  
  
  
  