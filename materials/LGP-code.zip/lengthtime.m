function timelength=lengthtime(beta)
revbeta=fliplr(beta);
if (sum(beta==0,2)==5 && beta(1)>0)  timelength=3.5; end
if (sum(beta==0,2)==5 && beta(1)<0)  timelength=0; end
if (sum(beta==0,2)<5)
root=roots(revbeta);
root=root(real(root)==root);
subroot = sort(root(root<=3.5 & root>=0));
subrootend = [0,subroot',3.5];
inter = (subrootend(1:(length(subrootend)-1))+subrootend(2:length(subrootend)))/2;
vainter = polyval(revbeta,inter);
id = find(vainter>0);
timelength = sum(subrootend(id+1)-subrootend(id));
end
end