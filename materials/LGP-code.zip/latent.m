%invC=invC1; e=e1; a=a1(:,:,s-1); g=g1(:,:,s);

function a = latent(invC,a0,e,a,g)
[N,n]=size(a);
z = zeros(N,n);
z = a-g;
for j=1:N
    for i=1:n
        c=-1/(invC(i,i))*invC(i,:);
        c(i)=[];
        va=z(j,~ismember(z(j,:),z(j,i)));
        bound = (a0-g(j,i)-dot(c,va))/sqrt(1/(invC(i,i)));
         if (bound>7) bound=7; end
        if e(j,i)==1
            z(j,i)=dot(c,va)+sqrt(1/(invC(i,i)))*truncnormrnd(1,0,1,bound,Inf);
       else z(j,i)=dot(c,va)+sqrt(1/(invC(i,i)))*truncnormrnd(1,0,1,-Inf,bound);
        end
     end
end
a = z+g;

