%theta=theta1(s-1,:);input=train;a=a1(:,:,s);g=g1(:,:,s);
function gradf=gradient(theta, input, a, g, thetaprior)
t=input;
[N,n] = size(a); 
C=gpcov(theta,input);
invC = inv(C);
C1=zeros(n,n);
C2=zeros(n,n);
C3=zeros(n,n);
for i=1:n
    for j=1:n
        %C2(i,j)=-theta(1)^2*exp(-theta(2)^2*sin(pi*theta(3)*(input(i)-input(j)))^2)*2*theta(2)*sin(pi*theta(3)*(input(i)-input(j)))^2;
        %C3(i,j)=theta(1)^2*exp(-theta(2)^2*sin(pi*theta(3)*(input(i)-input(j)))^2)*(-theta(2)^2)*2*sin(pi*theta(3)*(input(i)-input(j)))*cos(pi*theta(3)*(input(i)-input(j)))*pi*(input(i)-input(j));
        C2(i,j)=-theta(1)^2*exp(-theta(2)^2*(sin(pi*(t(i)-t(j))/theta(3)))^2)*2*theta(2)*(sin(pi*(t(i)-t(j))/theta(3)))^2;
        C3(i,j)=theta(1)^2*exp(-theta(2)^2*(sin(pi*(t(i)-t(j))/theta(3)))^2)*theta(2)^2*2*sin(pi*(t(i)-t(j))/theta(3))*cos(pi*(t(i)-t(j))/theta(3))*pi*(t(i)-t(j))/(theta(3)^2);
        %C2(i,j)=-theta(1)*exp(-theta(2)*(sin(pi*(t(i)-t(j))/theta(3)))^2)*(sin(pi*(t(i)-t(j))/theta(3)))^2;
        %C3(i,j)=theta(1)*exp(-theta(2)*(sin(pi*(t(i)-t(j))/theta(3)))^2)*theta(2)*2*sin(pi*(t(i)-t(j))/theta(3))*cos(pi*(t(i)-t(j))/theta(3))*pi*(t(i)-t(j))/(theta(3)^2);
    end
end
C1 = 2*theta(1)*exp(-sin(pi/theta(3)*(input'*ones(1,n)-ones(n,1)*input)).^2*theta(2)^2);
%C1 = exp(-sin(pi/theta(3)*(input'*ones(1,n)-ones(n,1)*input)).^2*theta(2));

vb1=trace((a-g)*invC*C1*invC*(a-g)');
vb2=trace((a-g)*invC*C2*invC*(a-g)');
vb3=trace((a-g)*invC*C3*invC*(a-g)');


gradf(1)=0.5*N*trace(invC*C1)-0.5*vb1+(theta(1)-thetaprior(1))/thetaprior(2)^2;
gradf(2)=0.5*N*trace(invC*C2)-0.5*vb2+(theta(2)-thetaprior(1))/thetaprior(2)^2;
gradf(3)=0.5*N*trace(invC*C3)-0.5*vb3+(theta(3)-thetaprior(1))/thetaprior(2)^2;

% inverse-gamma
% gradf(1)=0.5*N*trace(invC*C1)-0.5*vb1+(thetaprior(1)+1)/theta(1)-thetaprior(2)/(theta(1)^2);
% gradf(2)=0.5*N*trace(invC*C2)-0.5*vb2+(thetaprior(1)+1)/theta(2)-thetaprior(2)/(theta(2)^2);
% gradf(3)=0.5*N*trace(invC*C3)-0.5*vb3+(thetaprior(1)+1)/theta(3)-thetaprior(2)/(theta(3)^2);





