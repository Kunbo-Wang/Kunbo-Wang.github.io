function energy=energy_pos(theta, input, a, g, thetaprior)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%inverse gamma prior for theta
[N,n] = size(a); 
C=gpcov(theta,input);
invC = inv(C);
logdetC = 2*sum(log(diag(chol(C))));            % don't compute det(Q) directly
va=trace((a-g)*invC*(a-g)');
%for i=1:N
%    va=va+a(i,:)*invC*a(i,:)';
%end
energy=0.5*N*logdetC+0.5*va+0.5*(theta(1)-thetaprior(1))^2/thetaprior(2)^2+0.5*(theta(2)-thetaprior(1))^2/thetaprior(2)^2+0.5*(theta(3)-thetaprior(1))^2/thetaprior(2)^2;
%energy=0.5*N*logdetC+0.5*va+0.5*(theta(1)-thetaprior(1))^2/thetaprior(2)^2+(thetaprior(1)+1)*log(theta(1))+thetaprior(2)/theta(1)+(thetaprior(1)+1)*log(theta(2))+thetaprior(2)/theta(2)+(thetaprior(1)+1)*log(theta(3))+thetaprior(2)/theta(3);



