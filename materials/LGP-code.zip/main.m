
function exitcode= main(seed)
rand('state',26); % set arbitrary seed for uniform draws
randn('state',26); 
%generate data
K=35; %the time points
t=(1:K)/10; %scale the time points
N1=100; %the number of patients in control group
N2=100; %the number of patients in treatment group 
N=N1+N2;
%e=zeros(N,K);
%the variance-covariance matrix     
theta=[1 2 3.5];
C=zeros(K,K);
C=gpcov(theta,t);

% %scenario11
% truth_beta0=[ -2    3.5000  -1.0000];
% truth_beta1=[ -1.400    7.5000   -5.3000    1.0000];
% truth_g1=truth_beta0(1)+truth_beta0(2)*t+truth_beta0(3)*t.^2;
% truth_g2=truth_beta1(1)+truth_beta1(2)*t+truth_beta1(3)*t.^2+truth_beta1(4)*t.^3;
% 
% 
% % %scenario12
% truth_beta0=[ -1.5000    7.5000   -5.3000    1.0000];
% truth_beta1=[ -1    3.5000  -1.0000];
% truth_g1=truth_beta0(1)+truth_beta0(2)*t+truth_beta0(3)*t.^2+truth_beta0(4)*t.^3;
% truth_g2=truth_beta1(1)+truth_beta1(2)*t+truth_beta1(3)*t.^2;
% % 
% % %scenario13
% truth_beta0=[ -2.400    7.5000   -5.3000    1.0000];
% truth_beta1=[ -2.4    3.5000  -1.0000];
% truth_g1=truth_beta0(1)+truth_beta0(2)*t+truth_beta0(3)*t.^2+truth_beta0(4)*t.^3;
% truth_g2=truth_beta1(1)+truth_beta1(2)*t+truth_beta1(3)*t.^2;
% % % 
% % 
% %scenario14
% truth_beta0=[ -2.000    7.5000   -5.3000    1.0000];
% truth_beta1=[ -1    3.5000  -1.0000];
% truth_g1=truth_beta0(1)+truth_beta0(2)*t+truth_beta0(3)*t.^2+truth_beta0(4)*t.^3;
% truth_g2=truth_beta1(1)+truth_beta1(2)*t+truth_beta1(3)*t.^2;

% %scenario15
truth_beta0=[ -2    3.5000  -1.0000];
truth_beta1=[ -1.3  3.5000  -1];
truth_g1=truth_beta0(1)+truth_beta0(2)*t+truth_beta0(3)*t.^2;
truth_g2=truth_beta1(1)+truth_beta1(2)*t+truth_beta1(3)*t.^2;

% %scenario16
% truth_beta0=[ -2    3.5000  -1.0000];
% truth_beta1=[ -1.7  3.5000  -1];
% truth_g1=truth_beta0(1)+truth_beta0(2)*t+truth_beta0(3)*t.^2;
% truth_g2=truth_beta1(1)+truth_beta1(2)*t+truth_beta1(3)*t.^2;

% %scenario17
% truth_beta0=[ -1.28    3.5000  -1.0000];
% truth_beta1=[ -1.2  3.6000  -1];
% truth_g1=truth_beta0(1)+truth_beta0(2)*t+truth_beta0(3)*t.^2;
% truth_g2=truth_beta1(1)+truth_beta1(2)*t+truth_beta1(3)*t.^2;

% %scenario18
% truth_beta0=[-0.39 0.3];
% truth_beta1=[-1.1 1];
% truth_g1=truth_beta0(1)+truth_beta0(2)*t;
% truth_g2=truth_beta1(1)+truth_beta1(2)*t;

% %scenario19
% truth_beta0=[-0.39 0.3];
% truth_beta1=[-0.7 1];
% truth_g1=truth_beta0(1)+truth_beta0(2)*t;
% truth_g2=truth_beta1(1)+truth_beta1(2)*t;
% 
% 
% % %scenario20
% truth_beta0=[-0.39 0.3];
% truth_beta1=[-1.2*0.8 0.8];
% truth_g1=truth_beta0(1)+truth_beta0(2)*t;
% truth_g2=truth_beta1(1)+truth_beta1(2)*t;


% %scenario21
% truth_beta0=[-0.52 0.4];
% truth_beta1=[-1.1 1];
% truth_g1=truth_beta0(1)+truth_beta0(2)*t;
% truth_g2=truth_beta1(1)+truth_beta1(2)*t;



a=zeros(N,K);
for j=1:N1
   a(j,:)=mvnrnd(truth_g1,C);
end
for j=N1+1:N1+N2
   a(j,:)=mvnrnd(truth_g2,C);
end

a1=a;
a0=0;

for i=1:N
    for j=1:K
        e1(i,j)=(a(i,j)>a0);
    end
end

%sum(sum(e1(1:100,:)'))/100
%sum(sum(e1(101:200,:)'))/100

% truth=zeros(2,3);
%     for j=(K-2):K
%         truth(1,j-(K-3))=1-normcdf(a0,truth_g1(j),sqrt(C(j,j)));
%         truth(2,j-(K-3))=1-normcdf(a0,truth_g2(j),sqrt(C(j,j)));
%     end
% truth=zeros(2,35);
%     for j=1:K
%         truth(1,j)=1-normcdf(a0,truth_g1(j),sqrt(C(j,j)));
%         truth(2,j)=1-normcdf(a0,truth_g2(j),sqrt(C(j,j)));
%     end


seed=str2num(seed);
rand('state',seed); % set arbitrary seed for uniform draws
randn('state',seed); 

result=zeros(K,1);
N11=zeros(K,1);
N21=zeros(K,1);
for k=1:22
N11(k)=randsample(2:4,1);
end
N21(1:22)=N11(1:22);
for K=23:34
    K
recru=randsample(2:5,1);
N11(K)=recru
N21(K)=recru;
a0=0;
nparams=3;
t=(1:K)/10;
N1=min(sum(N11(1:K)),100);
N2=min(sum(N21(1:K)),100);
N=N1+N2;

S=2000;


%store simulated values
a=zeros(N,K,S);
z=zeros(N,K,S);
beta0=zeros(S,6);
beta1=zeros(S,6);
theta=zeros(S,nparams);
C=zeros(K,K);
g=zeros(N,K,S);
m1=zeros(1,S);
m2=zeros(1,S);


%initial values
theta(1,:)=[1 2 3.5];
a(:,:,1)=a1([(1:N1),(101:(100+N2))],1:K);
e=e1([(1:N1),(101:(100+N2))],1:K);

for i=1:N1
    g(i,:,1)=truth_g1(1:K);
end
for i=(N1+1):N
    g(i,:,1)=truth_g2(1:K);
end


%prior information
priorvar_beta=100;
thetaprior = [0 10];

for s=2:S
    %if (mod(s,100)==0) in=s
    %end

%simulate a
C = gpcov(theta(s-1,:),t);
z(:,:,s-1) = a(:,:,s-1)-g(:,:,s-1);
invC=inv(C);

%for i=1:N
%    for j=1:K
%        z(i,j,s-1)=a(i,j,s-1)-g(i,j,s-1);
%    end
%end

for j=1:N
    c=-1/(invC(1,1))*invC(1,:);
    c(1)=[];
    va=z(j,2:K,s-1);
    if e(j,1)==1
    z(j,1,s)=dot(c,va)+sqrt(1/(invC(1,1)))*norminv(unifrnd(normcdf((a0-g(j,1,s-1)-dot(c,va))/sqrt(1/(invC(1,1)))),1));
    else z(j,1,s)=dot(c,va)+sqrt(1/(invC(1,1)))*norminv(unifrnd(0,normcdf((a0-g(j,1,s-1)-dot(c,va))/sqrt(1/(invC(1,1))))));
    end
    
      
     for i=2:(K-1)
        c=-1/(invC(i,i))*invC(i,:);
        c(i)=[];
        va=[z(j,1:(i-1),s),z(j,(i+1):K,(s-1))];
        if e(j,i)==1
            z(j,i,s)=dot(c,va)+sqrt(1/(invC(i,i)))*norminv(unifrnd(normcdf((a0-g(j,i,s-1)-dot(c,va))/sqrt(1/(invC(i,i)))),1));
       else z(j,i,s)=dot(c,va)+sqrt(1/(invC(i,i)))*norminv(unifrnd(0,normcdf((a0-g(j,i,s-1)-dot(c,va))/sqrt(1/(invC(i,i))))));
        end
     end
    
      c=-1/(invC(K,K))*invC(K,:);
    c(K)=[];
    va=z(j,1:(K-1),s);
    if e(j,K)==1
    z(j,K,s)=dot(c,va)+sqrt(1/(invC(K,K)))*norminv(unifrnd(normcdf((a0-g(j,K,s-1)-dot(c,va))/sqrt(1/(invC(K,K)))),1));
    else z(j,K,s)=dot(c,va)+sqrt(1/(invC(K,K)))*norminv(unifrnd(0,normcdf((a0-g(j,K,s-1)-dot(c,va))/sqrt(1/(invC(K,K))))));
    end
end

a(:,:,s) = z(:,:,s)+g(:,:,s-1);

w1=polydegree(t, N1, invC, a(1:N1,:,s), priorvar_beta);
w2=polydegree(t, N2, invC, a((N1+1):N,:,s), priorvar_beta);

w1=cumsum(w1);
u=rand(1);
for i=1:6
    if u<w1(i)  break;
    end
end
        m1(s)=i;
        if (i==1) X1=ones(K,1);
        else
        X1=ones(K,1);
        for j=1:(i-1)
        X1=[X1, t'.^j];
        end
        end
        betaorder1=i;
        priormean_beta1=zeros(1,betaorder1);
%i;

A=N1*X1'*invC*X1;
b=X1'*invC*sum(a(1:N1,:,s))';
mean_beta=inv(A+1/priorvar_beta*eye(betaorder1))*(b+1/priorvar_beta*eye(betaorder1)*priormean_beta1');
var_beta=inv(A+1/priorvar_beta*eye(betaorder1));
sigma = var_beta-(var_beta-var_beta')./2;
beta0(s,1:m1(s))=mvnrnd(mean_beta,sigma);

for i=1:N1
    g(i,:,s)=(X1*beta0(s,1:m1(s))')';
end

w2=cumsum(w2);
u=rand(1);
for i=1:6
    if u<w2(i)  break;
    end
end
        m2(s)=i;
        if (i==1) X2=ones(K,1);
        else
        X2=ones(K,1);
        for j=1:(i-1)
        X2=[X2, t'.^j];
        end
        end
        betaorder2=i;
        priormean_beta2=zeros(1,betaorder2);
%i

A=N2*X2'*invC*X2;
b=X2'*invC*sum(a((N1+1):N,:,s))';
mean_beta=inv(A+1/priorvar_beta*eye(betaorder2))*(b+1/priorvar_beta*eye(betaorder2)*priormean_beta2');
var_beta=inv(A+1/priorvar_beta*eye(betaorder2));
sigma = var_beta-(var_beta-var_beta')./2;
beta1(s,1:m2(s))=mvnrnd(mean_beta,sigma);
for i=(N1+1):N
    g(i,:,s)=(X2*beta1(s,1:m2(s))')';
end


%simulate theta
theta(s,:)=hmc(theta(s-1,:),t, a(:,:,s), g(:,:,s),thetaprior);
end

nid=800;
StandardTime = zeros(nid,1);
ExpTime = zeros(nid,1);
for q=1:nid
    s=1200+q;
    StandardTime(q) = lengthtime(beta0(s,:));
    ExpTime(q) = lengthtime(beta1(s,:));
end
result(K) = sum(ExpTime>StandardTime+0.2)/nid;

if (sum(ExpTime>StandardTime+0.2)/nid>0.9) 
    break;
end

if (sum(ExpTime>StandardTime+0.2)/nid<0.1) 
    break;
end
end

file=[num2str(seed),'_N11_result.txt'];
save(file,'N11','result','StandardTime','ExpTime', '-ASCII')
exitcode=0
exit

