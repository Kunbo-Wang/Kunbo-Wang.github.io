%a2=a2(:,:,s);
function w=polydegree(train, N2, invC2, a2, priorvar_beta)
K = length(train);
w=zeros(1,6);
i=0;
X=ones(K,1);
betaorder=1;
    priormean_beta=zeros(1,betaorder);
    A=N2*X'*invC2*X;
    var_beta=inv(A+1/priorvar_beta*eye(betaorder));
    b=X'*invC2*sum(a2)';
    w(i+1)=log(sqrt(det(var_beta))/sqrt(det(priorvar_beta*eye(betaorder))))+1/2*b'*var_beta*b;
for i=1:5
    m=i;
    X=ones(K,1);
    for k=1:m
        X=[X, train'.^k];
    end
    betaorder=m+1;
    priormean_beta=zeros(1,betaorder);
    A=N2*X'*invC2*X;
    var_beta=inv(A+1/priorvar_beta*eye(betaorder));
    b=X'*invC2*sum(a2)';
    w(i+1)=log(sqrt(det(var_beta))/sqrt(det(priorvar_beta*eye(betaorder))))+1/2*b'*var_beta*b;
end
w=exp(w-max(w))/sum(exp(w-max(w)));
