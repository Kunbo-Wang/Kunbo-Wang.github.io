function C=gpcov(theta,input)
%GPCOV Compute the n by n covariance matrix 
%
%    USAGE: C = gpcov(theta, input) 
%
%    where: 
%
%    theta      is a list of hyperparameters
%    input  is matrix of training inputs
%    C      is a n by n matrix of covariance function
%
%    The form of the covariance function is
%
%    C(i,j) = theta(1)*exp(-(theta(2)*sin(pi*(t(i)-t(j))/theta(3)))^2)+theta(4)*exp(-theta(5)*(t(i)-t(j))^2)+theta(6)*t(i)*t(j)+0.01*(i==j);
%    where the third term is linear, the second non-linear and the first periodity and the final term
%    with the kronecker delta is the noise contribution. In this function, the
%    hyperparameters are collected in the vector theta as
%    follows:
%
%    theta = [log(theta)];
n = length(input); 
C = zeros(n,n);
C = C + theta(1)^2*exp(-theta(2)^2*(sin(pi/theta(3)*(input'*ones(1,n)-ones(n,1)*input))).^2);
%C = C + theta(1)*exp(-theta(2)*(sin(pi/theta(3)*(input'*ones(1,n)-ones(n,1)*input))).^2);
%C = C + theta(4)^2*exp(-(input'*ones(1,n)-ones(n,1)*input).^2*theta(5)^2); %nonlinear contribution
%C = C + theta(4)^2*input'*input; %linear contribution 
%C = C + theta(5)^2;
C = C + 0.01*eye(n); %noise


%for i=1:n
%    for j=1:n
%C1(i,j) = theta(1)*exp(-(theta(2)*sin(pi*(t(i)-t(j)))^2))+theta(3)*exp(-theta(4)*(t(i)-t(j))^2)+theta(5)*t(i)*t(j)+0.01*(i==j);
%    end
%end
