*Title: A Nonparametric Bayesian Basket Trial Design
*Authors: Yanxun Xu, Peter Mueller, Apostolia M Tsimberidou, and Donald Berry 
*Contribution: Yanxun Xu is mainly responsible for writing the code. And ppmx package should be credited to Peter Mueller. 
*Contract info: yanxun.xu@jhu.edu
*R Configurations: 
R version 3.3.0 (2016-05-03)
Platform: x86_64-apple-darwin13.4.0 (64-bit)
Running under: OS X 10.13.2 (unknown)

locale:
[1] en_US.UTF-8/en_US.UTF-8/en_US.UTF-8/C/en_US.UTF-8/en_US.UTF-8

attached base packages:
[1] stats     graphics  grDevices utils     datasets  methods   base     

other attached packages:
[1] ppmx_1.0

loaded via a namespace (and not attached):
[1] tools_3.3.0 yaml_2.1.14

*Execute the code
####################################################################
###Note. To run the proposed trial design, you need to install the below ppmx package.
#Use the follwoing command to install
system("R CMD INSTALL ppmx_1.0.tar.gz")
####################################################################
1. The function main.R contrains the commands to run the simulation. At the beginning of the code, we have two variables: scenario and seed. Please feel free to change these two values. 
2. To replicate the figures and tables in the paper, the functions are in analysis.R.
1) The first part is to caluate H0 and H1. 
2) In the operating characteristics part, it reproduce the numbers in Table 3. 
3) The next two parts of analysis.R are to plot figures 2 and 3. 
3. Function compare.R reproduces the Figure 4 in the paper. 
