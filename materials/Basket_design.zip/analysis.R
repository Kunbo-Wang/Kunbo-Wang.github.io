#########################################################
#calcualte H0 and H1
####################################################################
load("results.RData")
thres1 = results[1,,1:15]
a1 = apply(as.matrix(thres1), 1, function(x) sum(x[which(x>0)]))
H0_utility = quantile(a1, 0.95)  
H0_utility
thres2 = results[2,,1:15]
a2 = apply(as.matrix(thres2), 1, function(x) sum(x[which(x>0)]))
H1_utility = quantile(a2, 0.10)  
H1_utility

########################################################
###Operating Characteristics
##################################################################################
H0_utility = 1.3
H1_utility = 20
load("results.RData")
####################################################################
#### scenario 3
thres1 = results[3,,1:15]
TSR = sum(thres1[,12]>0)/Nsimu
a = apply(as.matrix(thres1), 1, function(x) sum(x[which(x>0)]))
temp1 = apply(thres1, 1, function(x) which(x>0))
num1 = rep(0, Nsimu)
num2 = rep(0, Nsimu)
for (i in 1:Nsimu)
{
  num1[i]=length(which(temp1[[i]]!=12))
  num2[i]=ifelse(length(temp1[[i]])>0, length(which(temp1[[i]]!=12))/length(temp1[[i]]),0)
}
FSR = sum(num1) / (Nsimu*14) 
sum(num2) / Nsimu
FNR = sum(a<H0_utility)/Nsimu
FPR = sum(a>H1_utility)/Nsimu
PF3 = c(TSR, FSR, FNR, FPR)
PF3
#[1] 0.872 0.042 0.104 0.000
####################################################################
#### scenario 4 true: 3 12 14
thres1 = results[4,,1:15]
a = apply(as.matrix(thres1), 1, function(x) sum(x[which(x>0)]))
FPR = sum(a>H1_utility)/Nsimu
FNR = sum(a<H0_utility)/Nsimu
TSR1 = sum(thres1[,3]>0)
TSR2 = sum(thres1[,12]>0)
TSR3 = sum(thres1[,14]>0)
TSR = (TSR1 + TSR2 + TSR3) / (3*Nsimu)
temp1 = apply(thres1, 1, function(x) which(x>0))
num1 = rep(0, Nsimu)
num2 = rep(0, Nsimu)
for (i in 1:Nsimu)
{
  num1[i]=sum(!temp1[[i]] %in% c(3,12,14))
  num2[i]=ifelse(length(temp1[[i]])>0, length(which(!temp1[[i]]%in% c(3,12,14)))/length(temp1[[i]]),0)
}
FSR = sum(num1) / (12*Nsimu)
sum(num2) / Nsimu
PF4 = c(TSR, FSR, FNR, FPR)
PF4
#[1] 0.680 0.043 0.036 0.000

####################################################################
#### scenario 5 true: 3 7 12
thres1 = results[5,,1:15]
a = apply(as.matrix(thres1), 1, function(x) sum(x[which(x>0)]))
FPR = sum(a>H1_utility)/Nsimu
FNR = sum(a<H0_utility)/Nsimu
TSR1 = sum(thres1[,3]>0)
TSR2 = sum(thres1[,7]>0)
TSR3 = sum(thres1[,12]>0)
TSR = (TSR1 + TSR2 + TSR3) / (3*Nsimu)
temp1 = apply(thres1, 1, function(x) which(x>0))
num1 = rep(0, Nsimu)
num2 = rep(0, Nsimu)
for (i in 1:Nsimu)
{
  num1[i]=sum(!temp1[[i]] %in% c(3,7,12))
  num2[i]=ifelse(length(temp1[[i]])>0, length(which(!temp1[[i]]%in% c(3,7,12)))/length(temp1[[i]]),0)
}
sum(num2) / Nsimu
FSR = sum(num1) / (12*Nsimu)
PF5 = c(TSR, FSR, FNR, FPR)
PF5
#[1] 0.769 0.022 0.014 0.000

#### scenario 6 true: 2 7 12
thres1 = results[6,,1:15]
a = apply(as.matrix(thres1), 1, function(x) sum(x[which(x>0)]))
FPR = sum(a>H1_utility)/Nsimu
FNR = sum(a<H0_utility)/Nsimu
TSR1 = sum(thres1[,2]>0)
TSR2 = sum(thres1[,7]>0)
TSR3 = sum(thres1[,12]>0)
TSR = (TSR1 + TSR2 + TSR3) / (3*Nsimu)
temp1 = apply(thres1, 1, function(x) which(x>0))
num1 = rep(0, Nsimu)
num2 = rep(0, Nsimu)
for (i in 1:Nsimu)
{
  num1[i]=sum(!temp1[[i]] %in% c(2,7,12))
  num2[i]=ifelse(length(temp1[[i]])>0, length(which(!temp1[[i]]%in% c(2,7,12)))/length(temp1[[i]]),0)
}
FSR = sum(num1) / (12*Nsimu)
sum(num2) / Nsimu
PF6 = c(TSR, FSR, FNR, FPR)
PF6
#[1] 0.767 0.015 0.040 0.000

#### scenario 7 with ER
thres1 = results[7,,1:15]
TSR = sum(thres1[,12]>0)/Nsimu
a = apply(as.matrix(thres1), 1, function(x) sum(x[which(x>0)]))
temp1 = apply(thres1, 1, function(x) which(x>0))
num1 = rep(0, Nsimu)
num2 = rep(0, Nsimu)
for (i in 1:Nsimu)
{
  num1[i]=length(which(temp1[[i]]!=12))
  num2[i]=ifelse(length(temp1[[i]])>0, length(which(temp1[[i]]!=12))/length(temp1[[i]]),0)
}
FSR = sum(num1) / (Nsimu*14) 
sum(num2) / Nsimu
FNR = sum(a<H0_utility)/Nsimu
FPR = sum(a>H1_utility)/Nsimu
PF7 = c(TSR, FSR, FNR, FPR)
PF7


###########################################################
### Figure 2  patient allocation
###########################################################
##library needed
library(reshape)
library(ggplot2)
library(scales)
library(plyr)
require(gridExtra)
tmp1 = cumsum(c(15,10,50,13,12,20,100,30,25,30,5,60,5,5,20))
load("results.RData")
for (scenario in 3:6)
{
  thres = results[scenario,,]
  thres2 = as.matrix(thres[,16:415])
  tmp2 = thres2[,1:15]
  prob_pa <- c(sum(c(tmp2)) / length(c(tmp2)), 1-sum(c(tmp2)) / length(c(tmp2)))
  for (k in 2:15)
  {
    tmp2 = thres2[,(tmp1[k-1]+1):tmp1[k]]
    prob_pa <- c(prob_pa, c(sum(c(tmp2)) / length(c(tmp2)), 1-sum(c(tmp2)) / length(c(tmp2))))
  }
  if (scenario==3)
  {
    wt = rep(0, 30)
    wt[23:24] = prob_pa[23:24]
    data1 <- data.frame(mutation=rep(c("FGFR", "FGFR","BRAF", "BRAF","PIK3CA","PIK3CA","PTEN","PTEN","MET","MET"), 3), 
                        patient_allocation=wt, 
                        treatment=rep(c("TT", "C"), 15), 
                        tu = c(rep("BRCA",10), rep("Ovary",10), rep("Lung",10)))
    pdf(paste("plot/fig_pa_",scenario,".pdf",sep=""),family="Times",height=3.5,width=7)
    par(mar=c(3,3,1,1),mgp=c(1.75,.75,0))
    plot3 = ggplot(data1,aes(x=mutation,y=patient_allocation,fill=treatment), color=factor(treatment)) +  
      stat_summary(fun.y=mean,position=position_dodge(),geom="bar") +
      facet_wrap(~tu) + theme(text = element_text(size=9),aspect.ratio=0.5)+labs(title = "Scenario 3")
    print(plot3)
    dev.off()
  }
  if (scenario==4)
  {
    wt = rep(0, 30)
    wt[5:6] = prob_pa[5:6]
    wt[27:28] = prob_pa[13:14]
    wt[23:24] = prob_pa[23:24]
    data1 <- data.frame(mutation=rep(c("FGFR", "FGFR","BRAF", "BRAF","PIK3CA","PIK3CA","PTEN","PTEN","MET","MET"), 3),  
                        patient_allocation=wt, 
                        treatment=rep(c("TT", "C"), 15), 
                        tu = c(rep("BRCA",10), rep("Ovary",10), rep("Lung",10)))
    pdf(paste("plot/fig_pa_",scenario,".pdf",sep=""),family="Times",height=3.5,width=7)
    par(mar=c(3,3,1,1),mgp=c(1.75,.75,0))
    plot4 = ggplot(data1,aes(x=mutation,y=patient_allocation,fill=treatment), color=factor(treatment)) +  
      stat_summary(fun.y=mean,position=position_dodge(),geom="bar") +
      facet_wrap(~tu) + theme(text = element_text(size=9),aspect.ratio=0.5)+labs(title = "Scenario 4")
    print(plot4)
    dev.off()
  }
  if (scenario==5)
  {
    wt = rep(0, 30)
    wt[5:6] = prob_pa[5:6]
    wt[13:14] = prob_pa[13:14]
    wt[23:24] = prob_pa[23:24]
    data1 <- data.frame(mutation=rep(c("FGFR", "FGFR","BRAF", "BRAF","PIK3CA","PIK3CA","PTEN","PTEN","MET","MET"), 3),  
                        patient_allocation=wt, 
                        treatment=rep(c("TT", "C"), 15), 
                        tu = c(rep("BRCA",10), rep("Ovary",10), rep("Lung",10)))
    pdf(paste("plot/fig_pa_",scenario,".pdf",sep=""),family="Times",height=3.5,width=7)
    par(mar=c(3,3,1,1),mgp=c(1.75,.75,0))
    plot5 = ggplot(data1,aes(x=mutation,y=patient_allocation,fill=treatment), color=factor(treatment)) +  
      stat_summary(fun.y=mean,position=position_dodge(),geom="bar") +
      facet_wrap(~tu) + theme(text = element_text(size=9),aspect.ratio=0.5)+labs(title = "Scenario 5")    print(plot5)
    dev.off()
  }
  if (scenario==6)
  {
    wt = rep(0, 30)
    wt[3:4] = prob_pa[3:4]
    wt[13:14] = prob_pa[13:14]
    wt[23:24] = prob_pa[23:24]
    data1 <- data.frame(mutation=rep(c("FGFR", "FGFR","BRAF", "BRAF","PIK3CA","PIK3CA","PTEN","PTEN","MET","MET"), 3), 
                        patient_allocation=wt, 
                        treatment=rep(c("TT", "C"), 15), 
                        tu = c(rep("BRCA",10), rep("Ovary",10), rep("Lung",10)))
    pdf(paste("plot/fig_pa_",scenario,".pdf",sep=""),family="Times",height=3.5,width=7)
    par(mar=c(3,3,1,1),mgp=c(1.75,.75,0))
    plot5 = ggplot(data1,aes(x=mutation,y=patient_allocation,fill=treatment), color=factor(treatment)) +  
      stat_summary(fun.y=mean,position=position_dodge(),geom="bar") +
      facet_wrap(~tu) + theme(text = element_text(size=9),aspect.ratio=0.5)+labs(title = "Scenario 6")    
    print(plot5)
    dev.off()
  }
}

###########################################################
### Figure 3 population finding
###########################################################

##library needed
library(reshape)
library(ggplot2)
library(scales)
library(plyr)
require(gridExtra)
require("grid")
Nsimu = 500
num_cancertype = 3
num_mutetype = 5
for (scenario in c(3, 4,5,6))
{
  effect = matrix(0, num_mutetype, num_cancertype)
  colnames(effect) = c("BRCA", "Ovary","Lung")
  rownames(effect) = c("FGFR", "BRAF", "PIK3CA","PTEN","MET")
  effect1 = simu.scenario(scenario)
  effect1[which(effect1!=0)] = 1
  thres1 = results[scenario,,1:15]
  ##Truth
  data_truth <- data.frame(mutation=c("FGFR", "BRAF", "PIK3CA","PTEN","MET"), BRCA = effect1[,1], Ovary = effect1[,2], Lung=effect1[,3])
  melt.data.truth<-melt(data_truth, id.vars="mutation", variable_name="tumor_type")
  plot1 <- ggplot(melt.data.truth, aes(tumor_type, mutation)) + 
    geom_tile(aes(fill = value), colour = "white") + scale_fill_gradient(low = "white", high = "steelblue",limits=c(0, 1)) #+ theme(legend.position = "none")
  legend <- g_legend(plot1)
  plot1 <- plot1 + theme(legend.position="none",text = element_text(size=14),aspect.ratio=0.5)+labs(title = paste("Scenario ", scenario, " Truth", sep=""))  
  ##simulation results
  prop_pf6 = matrix(apply(thres1, 2, function(x) sum(x>0)/Nsimu), 5, 3)
  data_simu <- data.frame(mutation=c("FGFR", "BRAF", "PIK3CA","PTEN","MET"), BRCA = prop_pf6[,1], Ovary = prop_pf6[,2], Lung= prop_pf6[,3])
  melt.data.simu <- melt(data_simu,id.vars="mutation", variable_name="tumor_type")
  p <- ggplot(melt.data.simu, aes(tumor_type, mutation)) + 
    geom_tile(aes(fill = value), colour = "white") 
  plot2 <- p + scale_fill_gradient(low = "white", high = "steelblue",limits=c(0, 1))+ylab(NULL)+theme(legend.position="none",text = element_text(size=14),aspect.ratio=0.5)+
    labs(title = "Posterior Estimate")  
  pdf(paste("plot/fig_pf_",scenario,".pdf",sep=""),family="Times",height=2,width=7)
  par(mar=c(3,3,1,1),mgp=c(1.75,.75,0))
  grid.arrange(plot1, plot2,legend, ncol=3,widths=c(0.6, 0.6, 0.1))
  dev.off()
}


