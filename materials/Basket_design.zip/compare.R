
scenario = 3  #scenario
source("YANXUN.R")
source("main.R")
library(reshape)
library(ggplot2)
library(scales)
library(plyr)
require(gridExtra)
Nsimu = 500
num_cancertype = 3
num_mutetype = 5
#mg[,index_ty] = sample(1:3, dim(mg)[1],replace=T)
effect = matrix(0, num_mutetype, num_cancertype)
colnames(effect) = c("BRCA", "Ovary","Lung")
rownames(effect) = c("FGFR", "BRAF", "PIK3CA","PTEN","MET")
effect = simu.scenario(scenario)
#########NAIVE
true_surv=array(0, c(5, 3,Nsimu))
est_surv=array(0, c(5, 3,Nsimu))
for (seed in seq(1, Nsimu))
{
  print(seed)
  n=400
  tmp <- simu.data(n=400, seed, method=1)
  data = tmp[[1]]
  pvalue = t.test(data[which(data[,2]==0),1], data[which(data[,2]==1),2],alternative="less")$p.value
  for (k in 1:5)
  {
    for (j in 1:3){
      if (pvalue<0.05) 
      {
        true_mean = effect[k,j]
        est_mean = sum(data[which(data[,2]==1),1])/(0.04)/(1+length(which(data[,2]==1))/0.04)
      } else
      {
        true_mean = effect[k,j]
        est_mean = sum(data[which(data[,2]==0),1])/(0.04)/(1+length(which(data[,2]==0))/0.04)
      }
      true_surv[k, j, seed] = mean(exp(true_mean+0.04/2))
      est_surv[k, j, seed] = mean(exp( est_mean+0.04/2))
    }}
}

diff1 = c(mean(abs(true_surv[1,1,]-est_surv[1,1,])),mean(abs(true_surv[2,1,]-est_surv[2,1,])),
          mean(abs(true_surv[3,1,]-est_surv[3,1,])),mean(abs(true_surv[4,1,]-est_surv[4,1,])),
          mean(abs(true_surv[5,1,]-est_surv[5,1,])))
diff2 = c(mean(abs(true_surv[1,2,]-est_surv[1,2,])),mean(abs(true_surv[2,2,]-est_surv[2,2,])),
          mean(abs(true_surv[3,2,]-est_surv[3,2,])),mean(abs(true_surv[4,2,]-est_surv[4,2,])),
          mean(abs(true_surv[5,2,]-est_surv[5,2,])))
diff3 = c(mean(abs(true_surv[1,3,]-est_surv[1,3,])),mean(abs(true_surv[2,3,]-est_surv[2,3,])),
          mean(abs(true_surv[3,3,]-est_surv[3,3,])),mean(abs(true_surv[4,3,]-est_surv[4,3,])),
          mean(abs(true_surv[5,3,]-est_surv[5,3,])))
diff1[c(2,4)] = diff1[c(4,2)]
diff2[c(2,4)] = diff2[c(4,2)]
diff3[c(2,4)] = diff3[c(4,2)]
data_simu <- data.frame(mutation=c("FGFR", "BRAF", "PIK3CA","PTEN","MET"), BRCA = diff1, Ovary = diff2, Lung=diff3)
melt.data.simu <- melt(data_simu,id.vars="mutation", variable_name="tumor_type")
p <- ggplot(melt.data.simu, aes(tumor_type, mutation)) + 
  geom_tile(aes(fill = value), colour = "white") 
plot1 <- p + scale_fill_gradient(low = "white", high = "steelblue",limits=c(0, 0.5))#+theme(legend.position="none")
legend <- g_legend(plot1)
plot1 <- plot1 + theme(legend.position="none",text = element_text(size=14),aspect.ratio=0.5)+ggtitle("NAIVE")

########### Indep
pvalue = rep(0, 5)
true_surv=array(0, c(5, 3,Nsimu))
est_surv=array(0, c(5, 3,Nsimu))
for (seed in seq(1, Nsimu))
{
  print(seed)
  tmp <- simu.data(n=400, seed, method=1)
  data = tmp[[1]]  
  id_11 = which(data[,3]==1 & data[,2] ==1)
  id_10 = which(data[,3]==1 & data[,2] ==0)
  id_21 = which(data[,4]==1 & data[,2] ==1)
  id_20 = which(data[,4]==1 & data[,2] ==0)
  id_31 = which(data[,5]==1 & data[,2] ==1)
  id_30 = which(data[,5]==1 & data[,2] ==0)
  id_41 = which(data[,6]==1 & data[,2] ==1)
  id_40 = which(data[,6]==1 & data[,2] ==0)
  id_51 = which(data[,7]==1 & data[,2] ==1)
  id_50 = which(data[,7]==1 & data[,2] ==0)
  pvalue[1] = t.test(data[id_10,1], data[id_11,1],alternative="less")$p.value
  pvalue[2] = t.test(data[id_20,1], data[id_21,1],alternative="less")$p.value
  pvalue[3] = t.test(data[id_30,1], data[id_31,1],alternative="less")$p.value
  pvalue[4] = t.test(data[id_40,1], data[id_41,1],alternative="less")$p.value
  pvalue[5] = t.test(data[id_50,1], data[id_51,1],alternative="less")$p.value
  for (k in 1:5)
  {
    for (j in 1:3){
      if (pvalue[k]<0.05)
      {
        true_mean = effect[k,j]
        est_mean = sum(data[which(data[,2]==1 & data[,(k+2)]==1),1])/(0.04)/(1+length(which(data[,2]==1 & data[,(k+2)]==1))/0.04)
      } else
      {
        true_mean = effect[k,j]
        est_mean = sum(data[which(data[,2]==0 & data[,(k+2)]==1),1])/(0.04)/(1+length(which(data[,2]==0 & data[,(k+2)]==1))/0.04)
      }
      true_surv[k, j, seed] = mean(exp(true_mean+0.04/2))
      est_surv[k, j, seed] = mean(exp( est_mean+0.04/2))
    }}
}

diff1 = c(mean(abs(true_surv[1,1,]-est_surv[1,1,])),mean(abs(true_surv[2,1,]-est_surv[2,1,])),
          mean(abs(true_surv[3,1,]-est_surv[3,1,])),mean(abs(true_surv[4,1,]-est_surv[4,1,])),
          mean(abs(true_surv[5,1,]-est_surv[5,1,])))
diff2 = c(mean(abs(true_surv[1,2,]-est_surv[1,2,])),mean(abs(true_surv[2,2,]-est_surv[2,2,])),
          mean(abs(true_surv[3,2,]-est_surv[3,2,])),mean(abs(true_surv[4,2,]-est_surv[4,2,])),
          mean(abs(true_surv[5,2,]-est_surv[5,2,])))
diff3 = c(mean(abs(true_surv[1,3,]-est_surv[1,3,])),mean(abs(true_surv[2,3,]-est_surv[2,3,])),
          mean(abs(true_surv[3,3,]-est_surv[3,3,])),mean(abs(true_surv[4,3,]-est_surv[4,3,])),
          mean(abs(true_surv[5,3,]-est_surv[5,3,])))
diff1[c(2,4)] = diff1[c(4,2)]
diff2[c(2,4)] = diff2[c(4,2)]
diff3[c(2,4)] = diff3[c(4,2)]
data_simu <- data.frame(mutation=c("FGFR", "BRAF", "PIK3CA","PTEN","MET"), BRCA = diff1, Ovary = diff2, Lung=diff3)
melt.data.simu <- melt(data_simu,id.vars="mutation", variable_name="tumor_type")
p <- ggplot(melt.data.simu, aes(tumor_type, mutation)) + 
  geom_tile(aes(fill = value), colour = "white") 
plot2 <- p + scale_fill_gradient(low = "white", high = "steelblue",limits=c(0, 0.5))+theme(legend.position="none",text = element_text(size=14),aspect.ratio=0.5)+ggtitle("INDEP")
#print(plot2)

####our
load("results.RData")
thres = results[scenario,,]
thres1 = thres[,1:15]
a = apply(as.matrix(thres1), 1, function(x) which(x>0))
true_surv=array(0, c(5,3, Nsimu))
est_surv=array(0, c(5,3, Nsimu))
for (seed in 1:Nsimu)
{
  print(seed)
  tmp <- simu.data(n=400, seed, method=1)
  data = tmp[[1]] 
  id_subgroup = a[[seed]]
  for (i in 1:5)
  {
    for (j in 1:3)
    {
      tmp_id = (j-1)*5 + i
      if (tmp_id %in% id_subgroup==1) 
      {
        true_mean = effect[i,j]
        est_mean = sum(data[which(data[,2]==1 & data[,i+2]==1 & data[,j+7] ==1),1])/(0.04)/(1+length(which(data[,2]==1 & data[,i+2]==1 & data[,j+7] ==1))/0.04)
      } else
      {
        true_mean = effect[i, j]
        est_mean = sum(data[which(data[,2]==0 & data[,i+2]==1 & data[,j+7] ==1),1])/(0.04)/(1+length(which(data[,2]==0 & data[,i+2]==1 & data[,j+7] ==1))/0.04)        
      }
      true_surv[i,j,seed] = mean(exp(true_mean+0.04/2))
      est_surv[i,j,seed] = mean(exp(est_mean+0.04/2))
    }
  }  
}

diff1 = c(mean(abs(true_surv[1,1,]-est_surv[1,1,])),mean(abs(true_surv[2,1,]-est_surv[2,1,])),
          mean(abs(true_surv[3,1,]-est_surv[3,1,])),mean(abs(true_surv[4,1,]-est_surv[4,1,])),
          mean(abs(true_surv[5,1,]-est_surv[5,1,])))
diff2 = c(mean(abs(true_surv[1,2,]-est_surv[1,2,])),mean(abs(true_surv[2,2,]-est_surv[2,2,])),
          mean(abs(true_surv[3,2,]-est_surv[3,2,])),mean(abs(true_surv[4,2,]-est_surv[4,2,])),
          mean(abs(true_surv[5,2,]-est_surv[5,2,])))
diff3 = c(mean(abs(true_surv[1,3,]-est_surv[1,3,])),mean(abs(true_surv[2,3,]-est_surv[2,3,])),
          mean(abs(true_surv[3,3,]-est_surv[3,3,])),mean(abs(true_surv[4,3,]-est_surv[4,3,])),
          mean(abs(true_surv[5,3,]-est_surv[5,3,])))
data_simu <- data.frame(mutation=c("FGFR", "BRAF", "PIK3CA","PTEN","MET"), BRCA = diff1, Ovary = diff2, Lung= diff3)
melt.data.simu <- melt(data_simu,id.vars="mutation", variable_name="tumor_type")
p <- ggplot(melt.data.simu, aes(tumor_type, mutation)) + 
  geom_tile(aes(fill = value), colour = "white") 
plot3 <- p + scale_fill_gradient(low = "white", high = "steelblue",limits=c(0, 0.5))+theme(legend.position="none",text = element_text(size=14),aspect.ratio=0.5)+ggtitle("OURS")

pdf(paste("plot/fig_compare_",scenario,".pdf",sep=""),family="Times",height=3.5,width=8)
par(mar=c(3,3,0,0),mgp=c(1,.75,0))
grid.arrange(plot1, plot2, plot3,legend, ncol=4, widths=c(1.8, 1.8, 1.8, 0.5))
dev.off()

