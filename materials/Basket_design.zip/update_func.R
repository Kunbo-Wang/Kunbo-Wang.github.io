hyper <- function(data)
{
  hyper <- NULL
  hyper$alpha1 <- 0.1 #hyperparameters in the similarity function calculations
  hyper$alpha2 <- 0.1 
  hyper$mu <- mean(data[,1])
  hyper$sigma2 <- sd(data[,1])
  hyper$p1 <- 8 #in the utility function alpha
  hyper$p2 <- 4 #in the utility function gamma
  return(hyper)
}

data.extract <- function()
{
  mm=read.table("mvv.txt")
  mm=mm[mm[,18]==1,]    ##censoring status
  #mu=mm[,c(1,(c(6,9,12,2,4,14,8)+21),43,44)] ##10 columns: survival and all covariates
  mut_main_id = c(2,6,9,12,14)
  mut_rare_id = (1:21)[-mut_main_id] + 21
  mu=mm[,c(1,(mut_main_id+21),43,44)] ##BRAF, KRAS, PIK3CA, PTEN, TP53
  vl=log(as.numeric(mm[,14]))   #LDH
  LDH=(vl>mean(vl))   #LDH high or low
  tumor_type=as.numeric(mu[,7])-1  #tumor type
  treatment = mu[,8]
  log.response = mu[,1]
  #mg=cbind(log.response,treatment,LDH,mu[,2:6],tumor_type)
  mg=cbind(log.response,treatment,mu[,2:6],tumor_type)
  return(mg)
}

#a = mm[mm$tm == "MELANOMA",c(2,6,9,12,14)+21]
#a[is.na(a)]=0
#colSums(a)

#n=400; method=1
simu.data <- function(n=400, seed, method)
{
    set.seed(seed)
    num = matrix(c(15,10,50,13,12,20,100,30,25,30,5,60,5,5,20),ncol=3)
    tmp1 = cumsum(c(15,10,50,13,12,20,100,30,25,30,5,60,5,5,20))
    x = matrix(NA, n, 9)
    count = 1
    for (i in 1:3)
    {
        for (j in 1:5)
        {
            if (count==1)
            {
                x[1:tmp1[1], 2] = 1
                x[1:tmp1[1], 7] = 1
                count = count + 1
            } else
            {
                x[(tmp1[count-1]+1): tmp1[count], j+1] = 1
                x[(tmp1[count-1]+1): tmp1[count], i+6] = 1
                count = count + 1
            }
        }
    }
    x[is.na(x)] = 0
    x[,1] = rbinom(n, 1, 0.5)
    y = simu.response(x, effect, method=1)
    data = cbind(y, x)
    mis = matrix(1, n, 9)
    return(list(data, mis))
}

simu.data.treat <- function(n=400, seed, method, treatment)
{
  set.seed(seed)
  num = matrix(c(15,10,50,13,12,20,100,30,20,30,60,5,5,10,20),ncol=3)
  tmp1 = cumsum(c(15,10,50,13,12,20,100,30,20,30,60,5,5,10,20))
  x = matrix(NA, n, 9)
  count = 1
  for (i in 1:3)
  {
    for (j in 1:5)
    {
      if (count==1)
      {
        x[1:tmp1[1], 2] = 1
        x[1:tmp1[1], 7] = 1
        count = count + 1
      } else
      {
        x[(tmp1[count-1]+1): tmp1[count], j+1] = 1
        x[(tmp1[count-1]+1): tmp1[count], i+6] = 1
        count = count + 1
      }
    }
  }
  x[is.na(x)] = 0
  x[,1] = treatment
  id <- which(effect!=0,arr.ind = T)
  if (length(id)==0)
  {
    mean = 0
  } else
  {
    id1 = apply(x, 1, function(z) which(z==1))
    id2 = lapply(id1, function(z) {if (length(z)<3) 0 else z[1]*effect[z[2]-1,z[3]-6]})
    id3 = lapply(id2, function(z) rnorm(1, z, sig))
    lresponse = unlist(id3)
  }
  return(list(data, mis))
}

simu.data.compare <- function(n=170, seed, method)
{
  set.seed(seed)
  num = matrix(c(10, 100, 60),ncol=3)
  tmp1 = cumsum(c(10, 100, 60))
  x = matrix(NA, n, 9)
  count = 1
  for (i in 1:3)
  {
    for (j in 1)
    {
      if (count==1)
      {
        x[1:tmp1[1], 3] = 1
        x[1:tmp1[1], 7] = 1
        count = count + 1
      } else
      {
        x[(tmp1[count-1]+1): tmp1[count], 3] = 1
        x[(tmp1[count-1]+1): tmp1[count], i+6] = 1
        count = count + 1
      }
    }
  }
  x[is.na(x)] = 0
  x[,1] = rbinom(n, 1, 0.5)
  y = simu.response(x, effect, method=1)
  data = cbind(y, x)
  mis = matrix(1, n, 9)
  return(list(data, mis))
}

simu.response <- function(x, effect, method, sig=0.2)
{
  if (method==1) y = simu.response.normal(x, effect, sig)
  if (method==0) y = simu.response.logit(x, effect)
  return(y)
}

#x=data1[id1,-1]; sig=0.2
simu.response.normal <- function(x, effect, sig)
{
    n = dim(x)[1]
    id <- which(effect!=0,arr.ind = T)
    if (length(id)==0)
    {
        lresponse = rnorm(n, 0, sig)
    } else
    {
        id1 = apply(x, 1, function(z) which(z==1))
        id2 = lapply(id1, function(z) {if (length(z)<3) 0 else z[1]*effect[z[2]-1,z[3]-6]})
        id3 = lapply(id2, function(z) rnorm(1, z, sig))
        lresponse = unlist(id3)
    }
 return(lresponse)
}

simu.response.logit <- function(x, maineffect, interaction)
{
  ndim.main = dim(x)[2]
  ndim.interaction = length(interaction)
  cov.matrix = cbind(1, x)
  for (i in 1:ndim.interaction)
  {
    cov.matrix = cbind(cov.matrix, x[,(i+1)]*x[,1])
  }
  cov.matrix = as.matrix(cov.matrix)
  coeff = c(maineffect, interaction)
  n = dim(x)[1]
  lresponse = rbinom(n,1,exp(cov.matrix%*%coeff)/(1+exp(cov.matrix%*%coeff)))
  return(lresponse)
}

#hazard_diff = simu_diff_value;hazard_diff = true_hazard_diff;size=ans
calculate_utility <- function(hazard_diff, size)
{
  dim1 = dim(hazard_diff)[1]
  mc = dim(hazard_diff)[2]
  if (is.null(dim1)==1) 
  {
    dim2 = length(hazard_diff)
    ls1= (1/hyper_para$p1)*log(size[1:dim2,1])-(1/hyper_para$p2)*log(size[1:dim2,2]+1)
    ct = hazard_diff*exp(ls1)
  } else
  {
    ct = rep(0, dim1)
    ls1= (1/hyper_para$p1)*log(size)
    #-(1/hyper_para$p2)*log(size[1:dim1,2]+1)
    tmp1 = hazard_diff*exp(ls1)
    #for (i in 1:dim1)
    #{
    #  id = (which(tmp1[i,]==max(tmp1[i,])))[1]
    #  ct[i] = sum(tmp1[i,-id])/(mc-1)
    # }
    ct = rowSums(tmp1)/mc
  }
  return(ct)
}

#tt = tt0; thr=0.4; st=0.2;n=dim(cfx)[1]
calculate_true_hazard<-function(tt,thr,n=dim(cfx)[1],st=.2)
{
  af=c()
  for(i in 1:n)
  {
      cx=as.numeric(cfx[i,])
      id1 = which(cx==1)
      bl1 = effect[id1[1],id1[2]-5]
      a1 = hazard(bl1,st,tt)
      b1 = hazard(0,st,tt)
      if(abs(a1)>3.5) a1=3.5*sign(a1)
       if(abs(b1)>3.5) b1=3.5*sign(b1)
      af[i] = a1 - b1 - thr
  }
  ct = rep(0, n)
  size = c(15,10,50,13,12,20,100,30,20,30,60,5,5,10,20)
  ls1= (1/hyper_para$p1)*log(size)
  tmp1 = af*exp(ls1)
  ct = sum(tmp1)
  return(ct)
}

fun3<-function(i,data,tt,regression=regression,intercept=intercept,st=.2)
{
    cx=as.numeric(cfx[i,])
    patient_id = find_match(cx,data)
    if(max(patient_id)==0) ann=0
    if(max(patient_id)!=0)
    {
        an=c()
        for(ii in patient_id)
        {
            id1 = which(data[ii,-1]==1)
            bl1 = ifelse (length(id1)<3, 0, id1[1]*effect[id1[2]-1,id1[3]-6])
            a1 = hazard(bl1,st,tt)
            b1 = hazard(0,st,tt)
            if(abs(a1)>3.5) a1=3.5*sign(a1)
            if(abs(b1)>3.5) b1=3.5*sign(b1)
            an[ii]=a1-b1
        }
        ann=mean(an[patient_id])
    }
    return(ann)
}

#data_match=data1_miss
find_match<-function(cx,data_match)
{
  rm=cx[cx!=0]
  in1=(which(cx!=0)+2)
  li=c()
  for(i in 1:dim(data_match)[1])
  {
    if(max(abs(data_match[i,in1]-rm))==0) li=c(li,i)  #find the unit whose covariate is the same as subgroup
  }
  if(is.null(li)) li=0
  return(li)
}

#mi=mean; st=sqrt(var); 
hazard <- function(mi,st,tt)
{
  ans=-log(-log(1-pnorm(tt,mi,st)))
  return(ans)
}




calculate_size<-function(ans)
{
  resu = matrix(cbind(ans, rowSums((cfx-1)>=0)), ,2)
  return(resu)
}

#group_cov <- control; mc <- 5; group_cov<-experiment
calculate_hazard <- function(data, group_cov, mc, tt, member, mu, V)
{
  prr=matrix(NA,dim(group_cov)[1],(mc))
  for(i in 1:dim(group_cov)[1])
  {
    tmp = calculate_survival(i, data, group_cov, member, mu, V, mc)
    mean = tmp[[1]]
    var = tmp[[2]]
    a1 = hazard(mean,sqrt(var),tt)
    id = which(abs(a1)>2.5)
    if (length(id)>0) a1[id] = 2.5*sign(a1[id])
    prr[i,] = a1
  }
  return(prr)
}

#mu <- "mu.mdp"; V<-"V.mdp";  member="member.mdp";covariate<-control; covariate<-experiment
calculate_survival <- function(ii, data_miss, covariate, member, mu, V, mc)
{
  mbb <- as.matrix(read.table(paste(member)))
  ncluster = mbb[,2]
  tmp = cumsum(ncluster)
  mu1 = read.table("mu.mdp")
  V1 = read.table("V.mdp")
  mu_cluster = list()
  V_cluster = list()
  mu_cluster[[1]] = mu1[1:ncluster[1],1]
  V_cluster[[1]] = V1[1:ncluster[1],1]
  for (i in 2:dim(mbb)[1])
  {
    mu_cluster[[i]] =  mu1[(tmp[i-1]+1):tmp[i],1]
    V_cluster[[i]] =  V1[(tmp[i-1]+1):tmp[i],1]
  }
  ww_mean = c()
  ww_var = c()
  for (mm in 0:(mc-1))
  {
    index = dim(mbb)[1]-mm
    my=as.vector(mbb[index,3:dim(mbb)[2]])
    w = c()
    for (j in 0:(ncluster[index]-1))
    {
      tmp1 = rbind(covariate[ii,2:dim(data_miss)[2]],data_miss[which(my==j),2:dim(data_miss)[2]])
      tmp2 = matrix(data_miss[which(my==j),2:dim(data_miss)[2]],ncol=dim(data_miss)[2]-1)
      n11 = colSums(tmp1==1)
      n10 = colSums(tmp1==0)
      n21 = colSums(tmp2==1)
      n20 = colSums(tmp2==0)
      g1 = log(beta(n11+0.1,n10+0.1))
      g2 = log(beta(n21+0.1,n20+0.1))
      #gc1 = sum(lgamma(table(tmp1[,10]) + 0.1)) - lgamma(sum(table(tmp1[,10]) + 0.1))
      #gc2 = sum(lgamma(table(tmp2[,10]) + 0.1)) - lgamma(sum(table(tmp2[,10]) + 0.1))
      w[j+1] = sum(g1 - g2) + log(sum(my==j)) 
    }
    tmpnew = covariate[ii,2:dim(data_miss)[2]]
    n1new = (tmpnew==1)
    n0new = (tmpnew==0)
    #gcnew = sum(lgamma(table(tmp1[10]) + 0.1)) - lgamma(sum(table(tmp1[10]) + 0.1)) + lgamma(0.3) - 3*lgamma(0.1)
    wnew = sum(log(beta(n1new+0.1,n0new+0.1)) -log(beta(hyper_para$alpha1, hyper_para$alpha2))) #+ gcnew
    w = c(w, wnew)
    spl=log(sum(exp(w-max(w))))+max(w)
    ppl=exp(w-spl)
    u <- sample(1:length(w),1, prob=ppl)
    if (u==length(w))
    {
      ww_mean[[mm+1]] = hyper_para$mu
      ww_var[[mm+1]]  = hyper_para$sigma2
    } else
    {
      ww_mean[[mm+1]] = mu_cluster[[index]][u]
      ww_var[[mm+1]] = V_cluster[[index]][u]
    }
    #ww_mean[[mm+1]] = sum(c(mu_cluster[[index]], hyper_para$mu)*ppl)
    #ww_var[[mm+1]] = sum(c(V_cluster[[index]], hyper_para$sigma2)*ppl^2)
  }
  return(list(ww_mean, ww_var))
}

# #mc: how many posterior samples we will use #mss: use missing data or not
# calculate_mean_sd <- function(data,member,mss,mc,tt)
# {
#   ww = wbn(data,member,mss,mc)
#   if(tt==0) ws=NULL
#   if(tt!=0) ws=calculate_sd(data,member,mc)
#   ans=list(ww,ws)
#   return(ans)
# }
# 
# wbn<-function(data,member,mss,mc)
# {
#   ww=c()
#   for(mm in 0:(mc-1)){
#     if(mss==0)	ww[[(mm+1)]]=wb(data,member,mm)
#     if(mss==1)  ww[[(mm+1)]]=wb2(data,member,mis,mm)
#   }
#   return(ww)
# }
# 
# wb<-function(data,member,mm=0)
# {
#   mbb=as.matrix(read.table(paste(member)))
#   my=as.vector(mbb[(dim(mbb)[1]-mm),3:dim(mbb)[2]])
#   k=max(my)
#   pm=dim(data)[2]
#   wk=matrix(0,k+1,(pm+1))
#   for(j in 0:k)
#   {
#     m23=data[which(my==j),]
#     if (is.null(dim(m23))==TRUE)
#     {
#       m23=t(as.matrix(m23))
#       mk=m23
#       l1=1/dim(data)[1]
#     }
#     if (is.null(dim(m23))==FALSE) 
#     {
#       mk=apply(m23,2,mean)
#       l1= (dim(m23)[1])/dim(data)[1]
#     }
#     wk[j+1,]=c(l1,mk)
#   }
#   return(wk)
# }
# 
# wb2 <- function(data,member,mis,mm=0)
# {
#   mbb=as.matrix(read.table(paste(member)))
#   my=as.vector(mbb[(dim(mbb)[1]-mm),3:dim(mbb)[2]])
#   k=max(my)
#   pm=dim(data)[2]
#   wk=matrix(0,k+1,(pm+1))
#   for(j in 0:k)
#   {
#     m23=data[which(my==j),]
#     mis3=mis[which(my==j),]
#     if (is.null(dim(m23))==TRUE) m23=t(as.matrix(m23))
#     if (is.null(dim(mis3))==TRUE) mis3=t(as.matrix(mis3))
#     mk=c()
#     for(jl in 1:dim(data)[2])
#     {
#       if(jl==1)  mk[jl]=mean(m23[,jl])
#       if(jl!=1)
#       {
#         lh=mis3[,(jl-1)]
#         lf=m23[,jl]
#         if (sum(lh)==0) mk[jl]=.5
#         if (sum(lh)!=0) mk[jl]=mean(lf[lh==1])
#       }
#     }
#     l1= (dim(m23)[1])/dim(data)[1]
#     wk[j+1,]=c(l1,mk)
#   }
#   return(wk)
# }

# calculate_sd <- function(data,member, mc)
# {
#   ws=c()
#   mbb=as.matrix(read.table(paste(member)))
#   pm=dim(data)[2]
#   for(mm in 0: (mc-1))
#   {
#     my=as.vector(mbb[(dim(mbb)[1]-mm),3:dim(mbb)[2]])
#     k=max(my)
#     aq=c()
#     for(j in 0:k)
#     {
#       if(sum(my==j)==1) aq[j+1]=.1
#       if(sum(my==j)>1) aq[j+1]=sd(data[(my==j),1])
#     }
#     ws[[mm+1]]=aq
#   }
#   return(ws)
# }

#group_cov=control; bin=1;
# calculate_hazard <- function(ww,group_cov,bin,tt=0,ws=NULL)
# {
#   mc=length(ww)
#   prr=matrix(NA,dim(group_cov)[1],(mc))
#   for(mm in 1:mc)
#   {
#     cluster_mean=ww[[mm]]  #the first column is proportion
#     cluster_sd=ws[[mm]]
#     m1=group_cov
#     for(i in 1:dim(m1)[1])
#     {
#       x=m1[i,2:dim(m1)[2]]
#       prr[i,mm]=p_mixture(x,cluster_mean, tt,cluster_sd)
#     }
#   }
#   return(prr)
# }

p_mixture <- function(x, cluster_mean,tt=0, cluster_sd=NULL)
{
  x=as.vector(x)
  pl=c()
  zl=c()
  for(k in 1:dim(cluster_mean)[1])
  {
    g = cluster_mean[k,3:dim(cluster_mean)[2]]
    if(length(x)<=9)
    {
      nv=which(x>=0)
      vl= sum(x[nv]*log(g[nv]+.001) +(1-x[nv])*log(1-g[nv]+.001) )
    }
    if(length(x)>9)
    {
      ng=(length(x)-14):(length(x))
      nvl=1:(length(x)-15)
      nv=which(x[nvl]>=0)
      vl1= sum(x[nv]*log(g[nv]+.001) +(1-x[nv])*log(1-g[nv]+.001) )
      vl=vl1+log(g[which(x[ng]==1)]+.001)
    }
    pl[k]=log(cluster_mean[k,1])+vl
    if(tt==0) zl[k]=(cluster_mean[k,2])
    if(tt!=0)
    {
      zl[k] = hazard(cluster_mean[k,2],cluster_sd[k],tt)
      if(zl[k]> acc) zl[k]=acc
      if(zl[k]<  -acc) zl[k]= -acc
    }
    #if(tt== -1) zl[k]=rnorm(1,cluster_mean[k,2],cluster_sd[k])
  }
  spl=log(sum(exp(pl-max(pl))))+max(pl)
  ppl=exp(pl-spl)
  ans=sum(zl*ppl)
  if(tt== -1) 
  {
    ai=sample(seq(1,dim(wk)[1]),ppl)
    ans=zl[ai]
  }
  return(ans)
}

#prp1=hazard_experiment; prp2=hazard_control
simu_hazard_diff <- function(data1_miss,hazard_experiment,hazard_control,mcc,cfx)
{
  fhp = matrix(NA, dim(cfx)[1], mcc)
  ans=c()
  for(i in 1:dim(cfx)[1])
  {  
    cx=as.numeric(cfx[i,])
    ans[[i]]=find_match(cx,data1_miss)
    if (max(ans[[i]])!=0 & length(ans[[i]])==1) fhp[i,] = hazard_experiment[ans[[i]],1:mcc]-hazard_control[ans[[i]],1:mcc]
    if(max(ans[[i]])!=0 & length(ans[[i]])>1)	fhp[i,]=colSums(hazard_experiment[ans[[i]],1:mcc]-hazard_control[ans[[i]],1:mcc])/length(ans[[i]])
    if(max(ans[[i]])==0)  fhp[i,]=rep(0, mcc)
  }
  return(list(fhp,ans))
}


simu.scenario <- function(scenario)
{
    if(scenario==1){
        effect = matrix(0, num_mutetype, num_cancertype)
    }
    if(scenario==2){
        effect = matrix(0.4, num_mutetype, num_cancertype)
    }
    if(scenario == 3)
    {
        effect[2,3] <- 0.4
    }
  if(scenario==4){
      effect[2,3] <- 0.3
      effect[3,1] <- 0.3
      effect[4,3] <- 0.4
  }
  if(scenario==5){
      effect[2,2] <- 0.4
      effect[3,1] <- 0.3
      effect[2,3] <- 0.3
  }
  if(scenario==6){
      effect[2,1] <- 0.4
      effect[2,2] <- 0.3
      effect[2,3] <- 0.4
  }
  if(scenario==13){
    effect[2,1] <- 0.4
    effect[2,2] <- 0.3
    effect[1,3] <- 0.4
  }
  if(scenario==7){
      effect = matrix(0.2, num_mutetype, num_cancertype)
      effect[2,2] = 0.4
  }
  if(scenario==8){
      effect = matrix(0.3, num_mutetype, num_cancertype)
      effect[2,2] = 0.4
  }
  if(scenario==9){
      effect = matrix(0.4, num_mutetype, num_cancertype)
  }
  if(scenario==10){
    intercept=0
    main=c(intercept,0.3, rep(0,8))
    interaction=c(rep(0,4),0, 0, 0, 0)
    third_interaction = NULL
  }
  if(scenario==12){
    intercept=0
    main=c(intercept,0, rep(0,8))
    interaction=c(rep(0,4),0, 0, 0, 0)
    third_interaction = NULL
  }
  return(effect)
}

g_legend<-function(a.gplot){
  tmp <- ggplot_gtable(ggplot_build(a.gplot))
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
  legend <- tmp$grobs[[leg]]
  return(legend)}

