#p1 is 1/alpha in f_{alpha, gamma}; p2 is 1/gamma
#mcc=5;member="member.mdp"; mu="mu.mdp"; V="V.mdp";tt=tt0; thr=0.1;
## patient allocation
main_pa <- function(data, mis, data_new, mcc=5,member="member.mdp",mu="mu.mdp", V="V.mdp",msn=1)
{
  #csn=0
  #^ works finest, 15,20 also work
  set.seed(7)
  
  #default values: the number of continuous p1=0, the number of categorical p2=9idx2 <- (p0+p1+1):(p0+p1+p2)
  ar=ppmx(Yin=data,mis=mis,p2=dim(data)[2]-1,n.iter=2000,n.discard=500,py=0,m.init=0,alpha=1,k0=1,bal=.1,ab=.5,cd=.5)

  #mcc=5;member="member.mdp"; mu="mu.mdp"; V="V.mdp";
  experiment=cbind(1,1,data_new[,-c(1,2)])
  control=cbind(1,0,data_new[,-c(1,2)])
  ndim = dim(control)[1]
  
    simu_pi = rep(0, ndim)
    for(i in 1:ndim)
    {
        surv_exp = calculate_survival(i, data, experiment, member, mu, V, mcc)
        surv_con = calculate_survival(i, data, control, member, mu, V, mcc)
        mean_exp = surv_exp[[1]]
        var_exp = surv_exp[[2]]
        mean_con = surv_con[[1]]
        var_con = surv_con[[2]]
        simu_pi[i] = mean(1 - pnorm(0, mean_exp - mean_con, sqrt(var_exp+var_con)))
        if (simu_pi[i]>0.9) simu_pi[i] = 0.9
        if (simu_pi[i]<0.1) simu_pi[i] = 0.1
    }
    u = runif(50)
    data1[id1, 2] = ifelse (u<simu_pi[(ndim-49): ndim], 1, 0)
    data1[id1, 1] = simu.response(data1[id1,-1], effect, method=1)
    return(data1[id1,])
}

main_pa_compare <- function(data, mis, data_new, mcc=5,member="member.mdp",mu="mu.mdp", V="V.mdp",msn=1)
{
  #csn=0
  #^ works finest, 15,20 also work
  set.seed(7)
  
  #default values: the number of continuous p1=0, the number of categorical p2=9idx2 <- (p0+p1+1):(p0+p1+p2)
  ar=ppmx(Yin=data,mis=mis,p2=dim(data)[2]-1,n.iter=2000,n.discard=500,py=0,m.init=0,alpha=1,k0=1,bal=.1,ab=.5,cd=.5)
  
  #mcc=5;member="member.mdp"; mu="mu.mdp"; V="V.mdp";
  experiment=cbind(1,1,data_new[,-c(1,2)])
  control=cbind(1,0,data_new[,-c(1,2)])
  ndim = dim(control)[1]
  
  simu_pi = rep(0, ndim)
  for(i in 1:ndim)
  {
    surv_exp = calculate_survival(i, data, experiment, member, mu, V, mcc)
    surv_con = calculate_survival(i, data, control, member, mu, V, mcc)
    mean_exp = surv_exp[[1]]
    var_exp = surv_exp[[2]]
    mean_con = surv_con[[1]]
    var_con = surv_con[[2]]
    simu_pi[i] = mean(1 - pnorm(0, mean_exp - mean_con, sqrt(var_exp+var_con)))
    if (simu_pi[i]>0.9) simu_pi[i] = 0.9
    if (simu_pi[i]<0.1) simu_pi[i] = 0.1
  }
  u = runif(21)
  data1[id1, 2] = ifelse (u<simu_pi[(ndim-20): ndim], 1, 0)
  data1[id1, 1] = simu.response(data1[id1,-1], effect, method=1)
  return(data1[id1,])
}



######function of population finding

main_pf <- function(data, mis, mcc=5,member="member.mdp",mu="mu.mdp", V="V.mdp",tt,thr, msn=1)
{
    #csn=0
    #^ works finest, 15,20 also work
    set.seed(7)
    
    #default values: the number of continuous p1=0, the number of categorical p2=9idx2 <- (p0+p1+1):(p0+p1+p2)
    ar=ppmx(Yin=data,mis=mis,p2=dim(data)[2]-1,n.iter=2000,n.discard=500,py=0,m.init=0,alpha=1,k0=1,bal=.1,ab=.5,cd=.5)
    
    #mcc=5;member="member.mdp"; mu="mu.mdp"; V="V.mdp";tt=tt0; thr=0.4;
    experiment=cbind(1,1,data[,-c(1,2)])
    control=cbind(1,0,data[,-c(1,2)])
    ndim = dim(control)[1]
    
    hazard_experiment = calculate_hazard(data, experiment, mcc, tt, member, mu, V) - thr
    hazard_control = calculate_hazard(data, control, mcc, tt, member, mu, V)
    
    
    simu_h_diff = simu_hazard_diff(data,hazard_experiment,hazard_control,mcc,cfx)
    simu_id = simu_h_diff[[2]]   #the id for each possible subgroup
    simu_diff_value = simu_h_diff[[1]] #the difference for each possible subgroup
    
    ans=c()
    for(i in 1:dim(cfx)[1])
    {
        if (sum(simu_id[[i]])==0) ans[i] = 0 else
        ans[i]=length(simu_id[[i]])
    }
    
    ans[ans<5] = 0
    ls1 = (1/hyper_para$p1)*log(ans)
    simu_utility = rowSums(simu_diff_value * exp(ls1))/mcc
    #id1 = which(simu_utility==max(simu_utility ))
    #thre = max(simu_utility )/exp(ls1)[id1]
    
    
    #size = calculate_size(ans)
    
    #true_hazard_diff = hazard_diff(tt,data,thr,regression=regression,intercept=intercept,st=.2)
    # ce is the utility of simuation
    #simu_utility = calculate_utility(simu_diff_value,size=ans)
    #order_simu = cfx[order(1-simu_utility),] #from the largest utility
    # ct is the utility of simulation truth
    # true_utility = calculate_utility(true_hazard_diff,size=size)
    #  order_true=cfx[order(1-true_utility),]
    #nlist_true = sum(true_utility>quantile(true_utility,pz))
    #nlist_simu = sum(simu_utility>quantile(simu_utility,py))
    #H1_utility <- (colSums(hazard_experiment-hazard_control)/dim(hazard_experiment)[1] - thr)
    #H1_utility <- sum(H1_utility*exp( (1/hyper_para$p1)*log(dim(hazard_experiment)[1])-(1/hyper_para$p2)*log(dim(data)[2]-1) ))/mcc
    #H1_utility <- sum(H1_utility*exp( (1/hyper_para$p1)*log(dim(hazard_experiment)[1])-(1/hyper_para$p2)*log(1) ))/mcc
    #a1=mean(hazard_experiment[,1:mcc]-hazard_control[,1:mcc])-thr
    #trp=rownames(order_true[1:nlist_true,])
    #erp2=rownames(order_simu[1:nlist_simu,])
    
    #lst_10=rownames(order_true[11,]) #can be any false subgroup in lower ranks
    #lst_20=rownames(order_true[21,]) #can be any false subgroup in lower ranks
    #TIE only meaningful when among top
    return(simu_utility)
}






















