##################################
###To run the proposed trial design, you need to install the below ppmx package.
#Use the follwoing command to install
#system("R CMD INSTALL ppmx_1.0.tar.gz")
##################################

scenario=1  ##You can change the scenario here
seed=1   #in the paper, we run 500 simulations for each scenario

library(ppmx)
source("update_func.R")
source("update_design.R")
mg = data.extract()
#extract the relevant covariates, mutations, ldh and cancer type
#original.data = mg[,-9]
#removing cancer type for simulations.
index_ty = dim(mg)[2]
num_cancertype = 3
num_mutetype = 5
mg[,index_ty] = sample(1:3, dim(mg)[1],replace=T)
 tumor_type_index = matrix(0, dim(mg)[1],3)
 for (i in 1:dim(mg)[1])
 {
   if (mg[i,index_ty]==1) tumor_type_index[i,] = c(1,0,0)
   if (mg[i,index_ty]==2) tumor_type_index[i,] = c(0,1,0)
   if (mg[i,index_ty]==3) tumor_type_index[i,] = c(0,0,1)
 }
 colnames(tumor_type_index) = c("BRCA", "Ovary","Lung")
 original.data = cbind(mg[,-index_ty], tumor_type_index)

cfx = cbind(apply(diag(5), 2, rep, 3),
rbind( apply(matrix(c(1,0,0), 1, 3), 2, rep, 5), apply(matrix(c(0,1,0), 1, 3), 2, rep, 5), apply(matrix(c(0,0,1), 1, 3), 2, rep, 5)  )  )

effect = matrix(0, num_mutetype, num_cancertype)
colnames(effect) = c("BRCA", "Ovary","Lung")
rownames(effect) = c("FGFR", "BRAF", "PIK3CA","PTEN","MET")
effect = simu.scenario(scenario)
tmp <- simu.data(n=400, seed=1, method=1)
data1 = tmp[[1]]
mis1 = tmp[[2]]
tt0 = log(quantile(exp(data1[,1]),.75))

  tmp <- simu.data(n=400, seed, method=1)
  data1 = tmp[[1]]
  mis1 = tmp[[2]]
  id = sample(1:400, 100, replace=F)
for (k in 1:6)  #we enroll the patients per cohort of 50
  {
      id1 = sample((1:400)[-id], 50, replace=F)
      data = data1[id,]
      mis = mis1[id,]
      hyper_para <- hyper(data)
      id <- c(id, id1)
      data_new <- data1[id1,]
      data1[id1,] = main_pa(data, mis, data_new) #after each cohort, get future patients' allocation probabilities
  }
az = main_pf(data1, mis1, tt=tt0, thr=0.4)  #after the trial is finished, find the subpopulation
#save the subpopulation finding results including the patient allocation
#write(c(az, data1[,2]),file=paste("ac_", scenario, "_", seed, ".txt",sep=""),ncolumns=415)

