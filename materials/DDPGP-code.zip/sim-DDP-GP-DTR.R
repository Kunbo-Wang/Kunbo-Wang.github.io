library(MASS)
library(survival)
library(mc2d)
library(foreach)
library(doMC)
registerDoMC(6)
source("update_pos.R")  #store all posterior
source("gibbs.R")
source("IPTW-sim-DTR.R")
source("sim-DTR-truth.R")
source("sim-DTR-LB.R")
#global variable
H = 10
Npat = 200
delta1 = 4 #prior for sigma2 let mean=1, var=0.5
delta2 = 3
lambda1 = 1 #prior for M
lambda2 = 1
mu0 = 0
tau2 = 1 #prior for theta

args <- commandArgs(TRUE)
if (length(args)!=1)
{
  stop("Arguments required: 1. seed (integer)")   
}
seed <- as.integer(eval(parse(text=args[1])))
T0 = rep(0, Npat)
censor_status_R = rep(0, Npat)
censor_status_C = rep(0, Npat)
baseline_cov = rnorm(Npat, 100, 10)
baseline_cov_scale = scale(baseline_cov)
front_ass = rbinom(Npat, 1, 0.5)
cov_frontline = matrix(c(rep(1,Npat),baseline_cov, front_ass), Npat, 3)
cov_frontline_scale = matrix(c(rep(1,Npat),baseline_cov_scale, front_ass), Npat, 3)
beta_R = c(2,0.02,0)
beta_C = c(1.5,0.03,-0.8)
T_R = exp(rnorm(Npat,cov_frontline%*%beta_R, 0.3))      
T_C = exp(rnorm(Npat,cov_frontline%*%beta_C, 0.3)) 
id_R = which(T_R<T_C)
id_C = which(T_R>=T_C)
TR = T_R[id_R]
TC = T_C[id_C]
censor_status_R[id_R] = 1
censor_status_C[id_C] = 1
T_front = rep(0, Npat)
T_front[id_R] = TR
T_front[id_C] = TC

######For Resistance patient
NRD = length(id_R)
censor_status_RD = rep(1, NRD)
salvage_R = ifelse(baseline_cov[id_R]<100, rbinom(NRD, 1, 0.8), rbinom(NRD, 1, 0.2))
cov_RD = matrix(c(rep(1,NRD),baseline_cov[id_R], front_ass[id_R], log(TR), salvage_R), NRD, 5)
cov_RD_scale = matrix(c(rep(1,NRD),baseline_cov_scale[id_R], front_ass[id_R], log(TR), salvage_R), NRD, 5)
beta_RD = c(-0.5, 0.03, 0.2, 0.5, 0.3)
TRD = exp(rnorm(NRD, cov_RD%*%beta_RD, 0.3))
TRD_censor = exp(rnorm(NRD, cov_RD%*%beta_RD+0.6, 0.3))
id_censor_RD = which(TRD_censor<TRD)
censor_status_RD[id_censor_RD] = 0
TRD[id_censor_RD] = TRD_censor[id_censor_RD]
id_censor = id_R[id_censor_RD]

########For CP patient
NC = length(id_C)
censor_status_CP = rep(1, NC)
cov_CP = matrix(c(rep(1,NC),baseline_cov[id_C], front_ass[id_C], log(TC)), NC, 4)
cov_CP_scale = matrix(c(rep(1,NC),baseline_cov_scale[id_C], front_ass[id_C], log(TC)), NC, 4)
beta_CP = c(1, 0.05, 1, -0.6)
TCP = exp(rnorm(NC, cov_CP%*%beta_CP, 0.3))
TCP_censor = exp(rnorm(NC, cov_CP%*%beta_CP+0.6, 0.3))
id_censor_CP = which(TCP_censor<TCP)
censor_status_CP[id_censor_CP] = 0
TCP[id_censor_CP] = TCP_censor[id_censor_CP]
id_censor = c(id_censor, id_C[id_censor_CP])

########For CPD patient
id_CPD = id_C[-id_censor_CP]
NCPD = length(id_CPD)
censor_status_CPD = rep(1,NCPD)
salvage_CPD = ifelse(baseline_cov[id_CPD]<100, rbinom(NCPD, 1, 0.2), rbinom(NCPD, 1, 0.85))
cov_CPD = matrix(c(rep(1,NCPD),baseline_cov[id_CPD], front_ass[id_CPD], log(TC[-id_censor_CP]),log(TCP[-id_censor_CP]), salvage_CPD), NCPD, 6)
cov_CPD_scale = matrix(c(rep(1,NCPD),baseline_cov_scale[id_CPD], front_ass[id_CPD], log(TC[-id_censor_CP]),log(TCP[-id_censor_CP]), salvage_CPD), NCPD, 6)
beta_CPD = c(0.8, 0.04, 1.5, -1, 0.5, 0.5)
TCPD = exp(rnorm(NCPD, cov_CPD%*%beta_CPD, 0.3))

for (i in 1:Npat)
{
  if (i %in% id_R) T0[i] = T_front[i] + TRD[id_R==i]
  if (i %in% id_CPD) T0[i] = T_front[i] + TCP[id_C==i] + TCPD[id_CPD==i]
  if (i %in% id_C & !(i %in%id_CPD)) T0[i] = T_front[i] + TCP[id_C==i]
}

set.seed(3)
censor_status_R0 = rep(0, Npat)
censor_status_C0 = rep(0, Npat)
baseline_cov0 = rnorm(Npat, 100, 10)
baseline_cov_scale0 = scale(baseline_cov0)
front_ass0 = rbinom(Npat, 1, 0.5)
cov_frontline0 = matrix(c(rep(1,Npat),baseline_cov0, front_ass0), Npat, 3)
cov_frontline_scale0 = matrix(c(rep(1,Npat),baseline_cov_scale0, front_ass0), Npat, 3)
beta_R0 = c(2,0.02,0)
beta_C0 = c(1.5,0.03,-0.8)
T_R0 = exp(rnorm(Npat,cov_frontline0%*%beta_R0, 0.3))      
T_C0 = exp(rnorm(Npat,cov_frontline0%*%beta_C0, 0.3)) 
id_R0 = which(T_R0<T_C0)
id_C0 = which(T_R0>=T_C0)
TR0 = T_R0[id_R0]
TC0 = T_C0[id_C0]
censor_status_R0[id_R0] = 1
censor_status_C0[id_C0] = 1

######For Resistance patient
NRD0 = length(id_R0)
censor_status_RD0 = rep(1, NRD0)
salvage_R0 = ifelse(baseline_cov0[id_R0]<100, rbinom(NRD0, 1, 0.8), rbinom(NRD0, 1, 0.2))
cov_RD0 = matrix(c(rep(1,NRD0),baseline_cov0[id_R0], front_ass0[id_R0], log(TR0), salvage_R0), NRD0, 5)
cov_RD_scale0 = matrix(c(rep(1,NRD0),baseline_cov_scale0[id_R0], front_ass0[id_R0], log(TR0), salvage_R0), NRD0, 5)
beta_RD0 = c(-0.5, 0.03, 0.2, 0.5, 0.3)
TRD0 = exp(rnorm(NRD0, cov_RD0%*%beta_RD0, 0.3))
TRD_censor0 = exp(rnorm(NRD0, cov_RD0%*%beta_RD0+0.6, 0.3))
id_censor_RD0 = which(TRD_censor0<TRD0)
censor_status_RD0[id_censor_RD0] = 0
TRD0[id_censor_RD0] = TRD_censor0[id_censor_RD0]
id_censor0 = id_R0[id_censor_RD0]

########For CP patient
NC0 = length(id_C0)
censor_status_CP0 = rep(1, NC0)
cov_CP0 = matrix(c(rep(1,NC0),baseline_cov0[id_C0], front_ass0[id_C0], log(TC0)), NC0, 4)
cov_CP_scale0 = matrix(c(rep(1,NC0),baseline_cov_scale0[id_C0], front_ass0[id_C0], log(TC0)), NC0, 4)
beta_CP0 = c(1, 0.05, 1, -0.6)
TCP0 = exp(rnorm(NC0, cov_CP0%*%beta_CP0, 0.3))
TCP_censor0 = exp(rnorm(NC0, cov_CP0%*%beta_CP0+0.6, 0.3))
id_censor_CP0 = which(TCP_censor0<TCP0)
censor_status_CP0[id_censor_CP0] = 0
TCP0[id_censor_CP0] = TCP_censor0[id_censor_CP0]
id_censor0 = c(id_censor0, id_C0[id_censor_CP0])

########For CPD patient
id_CPD0 = id_C0[-id_censor_CP0]
NCPD0 = length(id_CPD0)
censor_status_CPD0 = rep(1,NCPD0)
salvage_CPD0 = ifelse(baseline_cov0[id_CPD0]<100, rbinom(NCPD0, 1, 0.2), rbinom(NCPD0, 1, 0.85))
cov_CPD0 = matrix(c(rep(1,NCPD0),baseline_cov0[id_CPD0], front_ass0[id_CPD0], log(TC0[-id_censor_CP0]),log(TCP0[-id_censor_CP0]), salvage_CPD0), NCPD0, 6)
cov_CPD_scale0 = matrix(c(rep(1,NCPD0),baseline_cov_scale0[id_CPD0], front_ass0[id_CPD0], log(TC0[-id_censor_CP0]),log(TCP0[-id_censor_CP0]), salvage_CPD0), NCPD0, 6)
beta_CPD0 = c(0.8, 0.04, 1.5, -1, 0.5, 0.5)
TCPD0 = exp(rnorm(NCPD0, cov_CPD0%*%beta_CPD0, 0.3))

Niter = 5000
burn.in = 2000
lag = 10

mcmc_R = gibbs(Niter, log(T_front), cov_frontline_scale, censor_status_R)
mcmc_C = gibbs(Niter, log(T_front), cov_frontline_scale, censor_status_C)
mcmc_RD = gibbs(Niter, log(TRD), cov_RD_scale, censor_status_RD)
mcmc_CP = gibbs(Niter, log(TCP), cov_CP_scale, censor_status_CP)
mcmc_CPD = gibbs(Niter, log(TCPD), cov_CPD_scale, censor_status_CPD)

sim_IPTW = rep(0, 8)
sim_IPTW[1] = IPTW(1,1,1)
sim_IPTW[2] = IPTW(1,0,1)
sim_IPTW[3] = IPTW(1,0,0)
sim_IPTW[4] = IPTW(1,1,0)
sim_IPTW[5] = IPTW(0,0,0)
sim_IPTW[6] = IPTW(0,1,1)
sim_IPTW[7] = IPTW(0,1,0)
sim_IPTW[8] = IPTW(0,0,1)

sim_truth = rep(0, 8)
sim_truth[1] = Lbased_truth(1,1,1)
sim_truth[2] = Lbased_truth(1,0,1)
sim_truth[3] = Lbased_truth(1,0,0)
sim_truth[4] = Lbased_truth(1,1,0)
sim_truth[5] = Lbased_truth(0,0,0)
sim_truth[6] = Lbased_truth(0,1,1)
sim_truth[7] = Lbased_truth(0,1,0)
sim_truth[8] = Lbased_truth(0,0,1)

sim_DDP = rep(0, 8)
sim_DDP[1] = Lbased(1,1,1)
sim_DDP[2] = Lbased(1,0,1)
sim_DDP[3] = Lbased(1,0,0)
sim_DDP[4] = Lbased(1,1,0)
sim_DDP[5] = Lbased(0,0,0)
sim_DDP[6] = Lbased(0,1,1)
sim_DDP[7] = Lbased(0,1,0)
sim_DDP[8] = Lbased(0,0,1)

sim_DDP2 = rep(0, 8)
sim_DDP2[1] = Lbased2(1,1,1)
sim_DDP2[2] = Lbased2(1,0,1)
sim_DDP2[3] = Lbased2(1,0,0)
sim_DDP2[4] = Lbased2(1,1,0)
sim_DDP2[5] = Lbased2(0,0,0)
sim_DDP2[6] = Lbased2(0,1,1)
sim_DDP2[7] = Lbased2(0,1,0)
sim_DDP2[8] = Lbased2(0,0,1)

sim_result=cbind(sim_truth, sim_IPTW, sim_DDP, sim_DDP2)
write(t(sim_result), ncolumns=4, file=paste("out/",seed,"sim_result.txt",sep="_"))
