init <- function(response, Npat)
{
	hc = hclust(dist(response)^2, "cen")
	r = cutree(hc, k=H)
    wh1 <- table(r)/Npat
    idx <- order(wh1,decreasing=T)
    wh <- wh1[idx]
    mh = sapply(split(response,r),mean)
    muh = matrix(mh,H, Npat)
    M = 1
    sigma2 = 0.1
    return(list(muh=muh, wh=wh, M=M,sigma2=sigma2, r=r))
}

#sigma2=mcmc_PD$sigma2[iter-1]; muh=mcmc_PD$muh[,,iter-1]; wh=mcmc_PD$wh[,iter-1]; r=mcmc_PD$r[,iter-1]; betah=mcmc_PD$betah[,,iter]
#sigma2=mcmc$sigma2[iter-1]; muh=mcmc$muh[,,iter-1]; wh=mcmc$wh[,iter-1]; r=mcmc$r[,iter-1]; betah=mcmc$betah[,,iter-1]
update_r <- function(sigma2, muh, wh, betah, Npat, censor_status, response, r, covariance, cov)
{
  impute_y = response
	for (i in 1:Npat)
	{
	  mu = t(betah%*%cov[i,]) + covariance[i,-i]%*%chol2inv(chol(covariance[-i,-i]))%*%t(muh[,-i]-betah%*%t(cov[-i,]))
		if (censor_status[i]==1)
		{
			ph = dnorm(response[i], m=mu, sd=sqrt(sigma2))*wh
			#if (sum(ph==0)==H) r[i] = which(mu==max(mu)) else
		    r[i] = sample(1:H, 1, prob=ph)
		}
		if (censor_status[i] ==0)
		{
			ph = (1-pnorm(response[i], m=mu, sd=sqrt(sigma2)))*wh
			#if (sum(ph==0)==H) r[i] = which(mu==max(mu)) else 
		    r[i] = sample(1:H, 1, prob=ph)
			impute_y[i] = rtrunc(rnorm, 1, linf=response[i], lsup=Inf, mean = mu[r[i]], sd = sqrt(sigma2))
		}
	}
	return(list(r=r,impute_y=impute_y))
}

#r<-mcmc$r[,iter]; M=mcmc$M[iter-1]
update_wh <- function(r, M)
{
   ## returns: wh
    vh <- rep(0,H)  # initialize
    wh <- rep(0,H)
    V <-  1         # record prod_{g<h} (1-vh_h)
    for(h in 1:(H-1)){
      Ah <- which(r==h)
      Bh <- which(r>h)
      vh[h] <-  rbeta(1, 1+length(Ah), M+length(Bh))
      wh[h] <- vh[h]*V
      V <- V*(1-vh[h])
    }
    vh[H] <- 1.0
    wh[H] <- V
    return(wh)
}

#wh=mcmc_PD$wh[,iter-1]; r=mcmc_PD$r[,iter]; sigma2=mcmc_PD$sigma2[iter-1]; betah=mcmc_PD$betah[,,iter-1]
#wh=mcmc$wh[,iter-1]; r=mcmc$r[,iter]; sigma2=mcmc$sigma2[iter-1]; betah=mcmc$betah[,,iter-1]
update_muh <- function(wh,r, sigma2, response, Npat, covariance, cov, betah, inv_covariance)
{
	   muh <- matrix(0,H, Npat)     # initialize
	   for(h in 1:H){
	     if(any(r==h)){      # some data assigned to h-th pointmass
	       Sh <- which(r==h) 
	       nh <- length(Sh)
         W = matrix(0, nh, Npat)
         for (i in 1:nh)
         {
           W[i, Sh[i]] = 1
         }
	       var = chol2inv(chol(inv_covariance+1/sigma2*t(W)%*%W))
	       mu = var%*%(t(W)%*%response[Sh]/sigma2 + inv_covariance%*%cov%*%betah[h,])
	       muh[h,] <- mvrnorm(1, mu, var)
	     } else {            # no data assinged to h-th pointmass# sample from base measure
	       mu <- cov%*%betah[h,]
	       muh[h,] <- mvrnorm(1, mu, covariance)}
	   }
    
    return(muh)
}

#sigma2=mcmc$sigma2[iter-1];betah=mcmc$betah[,,iter]
update_muhCD <- function(sigma2, response, Npat, covariance, cov, betah, inv_covariance)
{
  muh <- rep(0, Npat)     # initialize
  var = chol2inv(chol(inv_covariance+1/sigma2*diag(Npat)))
  mu = var%*%(response/sigma2 + inv_covariance%*%cov%*%betah)
  muh <- mvrnorm(1, mu, var)
  return(muh)
}

#muh <- mcmc_PD$muh[,,iter]; 
update_betah <- function(Ncov, muh, cov, covariance, r, inv_covariance)
{
	betah <- matrix(0,H, Ncov)     # initialize
	var = solve(t(cov)%*%inv_covariance%*%cov+diag(Ncov))
     for(h in 1:H){
      if(any(r==h)){      # some data assigned to h-th pointmass
        mu = var%*%(t(cov)%*%inv_covariance%*%muh[h,] + diag(Ncov)%*%beta0)
        betah[h,] <- mvrnorm(1, mu, var)
      } else {            # no data assinged to h-th pointmass     # sample from base measure
        mu <- rep(0, Ncov) 
        betah[h,] <- mvrnorm(1, mu, diag(Ncov))}
    }
    return(betah)
}

#muh=mcmc$muh[,iter]
update_betahCD <- function(Ncov, muh, cov, covariance, inv_covariance)
{
  betah <- rep(0,Ncov)     # initialize
  var = solve(t(cov)%*%inv_covariance%*%cov+diag(Ncov))
  mu = var%*%t(cov)%*%inv_covariance%*%muh
  betah  <- mvrnorm(1, mu, var)
  return(betah)
}


#muh=mcmc_PD$muh[,,iter];r=mcmc_PD$r[,iter]; wh=mcmc_PD$wh[,iter]
update_sigma2 <- function(r, response, muh, Npat)
{
	tmp = rep(0, Npat)
	for (h in 1:H)
	{
		if(any(r==h))
		{
			Sh = which(r==h)
			tmp[Sh] = muh[h,Sh]
		}
	}
  inverse_sigma2 <- rgamma(1, delta1+Npat/2, delta2+sum((response-tmp)^2)/2)
	sigma2 <- 1/inverse_sigma2
	return(sigma2)
}
#muh=mcmc$muh[,iter]
update_sigma2CD <- function(response, muh, Npat)
{
  inverse_sigma2 <- rgamma(1, delta1+Npat/2, delta2+sum((response-muh)^2)/2)
  sigma2 <- 1/inverse_sigma2
  return(sigma2)
}

update_M <- function(Mold, Npat)
{
	m = rbeta(1, (Mold+1), Npat)
	ratio = (lambda1+H-1)/(Npat*(lambda2-log(m)))
	prop = ratio/(1+ratio)
	u = runif(1)
	if (u<prop){Mnew = rgamma(1, lambda1+H, lambda2-log(m))} else{
		Mnew = rgamma(1, lambda1+H-1, lambda2-log(m))}
	return(Mnew)
}

#theta = c(1,1,1)
update_cov <- function(Ncov, Npat, cov, theta)
{
	cova = matrix(0, Npat, Npat)
    for ( i in 1:Ncov)
    {
        cova = cova + theta[i]^2*outer(cov[,i],cov[,i],'-')^2
    }
    return(exp(-cova) + 0.01*diag(Npat))
}

#theta=mcmc$theta[,iter-1]; muh=mcmc$muh[,,iter];r=mcmc$r[,iter]
L <- function(theta, muh, Npat, cov, r, Ncov)
{
	cova = matrix(0, Npat, Npat)
    for ( i in 1:Ncov)
    {
        cova = cova + theta[i]^2*outer(cov[,i],cov[,i],'-')^2
    }
    covariance = exp(-cova) + 0.01*diag(Npat)
	sum1 = 0
	sum2 = 0
	for (h in 1:H)
	{
		if (any(r==h)){
		Ah = which(r==h)
		sum1 = sum1 + muh[h,Ah]%*%solve(covariance[Ah, Ah])%*%muh[h,Ah]
		if (length(Ah)==1) sum2 = sum2 + log(covariance[Ah,Ah]) else
		sum2 = sum2 + determinant(covariance[Ah, Ah], logarithm=TRUE)$modulus
	}}
	1/2*sum2 + 1/2*sum1 + sum((theta-mu0)^2/(2*tau2))
}

#nlm(L,c(1,1,1),muh=muh, Npat, cov, r=r, Ncov)


#dL(theta,muh,Npat,cov,r,Ncov)
dL <- function(theta, muh, Npat, cov, r, Ncov)
{
	par = rep(0, Ncov)
	ParC = array(0, c(Npat, Npat, Ncov))
	cova = matrix(0, Npat, Npat)
    for ( i in 1:Ncov)
    {
        cova = cova + theta[i]^2*outer(cov[,i],cov[,i],'-')^2
    }
    covariance = exp(-cova) + 0.01*diag(Npat)
	for (j in 1:Ncov)
	{
		ParC[,,j] = -2*theta[j]*covariance * outer(cov[,j],cov[,j],'-')^2
	}
	for (j in 1:Ncov)
	{
		sum2 = 0
		for (h in 1:H)
	    {
	    	if (any(r==h)){
		Ah = which(r==h)
		sum2 = sum2 -1/2*sum(diag(solve(covariance[Ah,Ah])%*%ParC[Ah,Ah,j])) + 1/2*muh[h,Ah]%*%solve(covariance[Ah,Ah])%*%ParC[Ah,Ah,j]%*%solve(covariance[Ah,Ah])%*%muh[h,Ah]
	    }}
	    par[j] = sum2 - sum((theta[j]-mu0)/(tau2))
	}
	return(par)
}

update_theta <- function(theta,muh,Npat,cov,r,Ncov)
{
	#hybridMC(y.start=theta, muh=muh, Npat=Npat, cov=cov, r=r, Ncov=Ncov, n.samp=1, logDens=L, dLogDens=dL,epsilon=.02,LFsteps=10)[1,]
}

#wh<-mcmc$wh[,iter]; muh=mcmc$muh[,,iter]; sigma2=mcmc$sigma2[iter];r=mcmc$r[,iter];covD=cov;
#wh<-mcmc_D$wh[,iter]; muh=mcmc_D$muh[,,iter]; sigma2=mcmc_D$sigma2[iter]; cov=covX[,2:8];covariance=covariance_D
#wh<-mcmc_RD$wh[,iter]; muh=mcmc_RD$muh[,,iter]; sigma2=mcmc_RD$sigma2[iter]; covariance=covariance_RD; covD=covRD;
fmean <- function(wh, muh, theta, cov, covD, inv_covariance, Npat, sigma2)
{
	fx = rep(0, Npat)
	for (i in 1:Npat)
	{
    coeff = t(covD)-cov[i,]
    c1 = exp(-colSums(coeff^2*theta^2))
    fx[i] = exp(sum(wh*c1%*%inv_covariance%*%t(muh)+1/2*wh^2*sigma2))
	}
	return(fx)
}

#wh=mcmc$wh[,iter]; muh=mcmc$muh[,,iter]
fbar <- function(wh, muh, betah, cov, covD, inv_covariance, Npat)
{
  fx = rep(0, Npat)
  for (i in 1:Npat)
  {
    coeff = t(covD)-cov[i,]
    c1 = exp(-colSums(coeff^2))
    fx[i] = sum(wh*(t(betah%*%cov[i,]) + c1%*%inv_covariance%*%(t(muh)-covD%*%t(betah))))
  }
  return(fx)
}
#wh<-mcmc$wh[,iter]; muh=mcmc$muh[,,iter]; sigma2=mcmc$sigma2[iter];r=mcmc$r[,iter];covD=cov;betah=mcmc$betah[,,iter];
fbarnew <- function(wh, muh, cov, covD, inv_covariance, Npat, sigma2, betah)
{
  fx = rep(0, Npat)
  for (i in 1:Npat)
  {
    coeff = t(covD)-cov[i,]
    c1 = exp(-colSums(coeff^2))
    fx[i] = exp(sum(wh*(t(betah%*%cov[i,]) + c1%*%inv_covariance%*%(t(muh)-covD%*%t(betah)))+1/2*wh^2*sigma2))
  }
  return(fx)
}

#wh=mcmc$wh[,iter]; muh=mcmc$muh[,,iter]; betah=mcmc$betah[,,iter]
fsurvival <- function(xgrid, wh, muh, betah, sigma2, dpat, inv_covariance,cov)
{
  fx <- rep(0, length(xgrid))
  for (h in 1:H)
  {
    #coeff = t(cov)-cov[dpat,]
    coeff = t(cov)-dpat
    c1 = exp(-colSums(coeff^2))
    #fx <- fx + wh[h]*pnorm(xgrid, m=betah[h,]%*%d[dpat,]+c1%*%inv_covariance%*%(muh[h,]-cov%*%betah[h,]), sd=sqrt(sigma2))
    fx <- fx + wh[h]*pnorm(xgrid, m=betah[h,]%*%dpat+c1%*%inv_covariance%*%(muh[h,]-cov%*%betah[h,]), sd=sqrt(sigma2))    
  }
  return(fx)
}
