#response=data_input$response$D; cov=data_input$cov$D; censor_status=data_input$censor_status$D
#response=data_input$response$RD; cov=data_input$cov$RD; censor_status=data_input$censor_status$RD
#response=data_input$response$CD; cov=data_input$cov$CD; censor_status=data_input$censor_status$CD
#response=data_input$response$PD; cov=data_input$cov$PD; censor_status=data_input$censor_status$PD
#response=log(T_front); cov=cov_frontline_scale;censor_status=censor_status_C
#response=log(TRD); cov=cov_RD_scale;censor_status=censor_status_RD
gibbs <- function(Niter, response, cov, censor_status)
{
	Npat = length(response)
	Ncov = dim(cov)[2]
  cov_minus = cov[,-1]
	lfit = survreg(Surv(response,censor_status)~cov_minus,dist="gaussian")
	beta0 = matrix(rep(lfit$coefficients, H),H,Ncov, byrow=T)[1,]
  
	  mcmc <- NULL
    mcmc$M <- rep(NA, Niter)
    mcmc$sigma2 <- rep(NA, Niter)
    mcmc$muh <- array(NA, c(H, Npat, Niter))
    mcmc$betah <- array(NA, c(H, Ncov, Niter))
    mcmc$r <- array(NA, c(Npat, Niter))
    mcmc$wh <- array(NA, c(H, Niter))
    mcmc$covariance <- array(NA, c(Npat, Npat, Niter))
    mcmc$theta <- matrix(NA, Ncov, Niter)
	  mcmc$imputey <- matrix(NA, Npat, Niter)
    
    

    ##Initialize 
    initial <- init(response, Npat)
    mcmc$M[1] = initial$M
    mcmc$sigma2[1] = initial$sigma2
    mcmc$muh[,,1] = initial$muh
    mcmc$wh[,1] = initial$wh
    mcmc$r[,1] = initial$r
    lfit = survreg(Surv(exp(response),censor_status)~cov,dist="weibull")
    mcmc$betah[,,1] = matrix(rep(lfit$coefficients[-2], H),H,Ncov, byrow=T)
   	mcmc$imputey[,1] = response

    #mcmc$theta[,1] = rep(1, Ncov)
    theta = rep(1, Ncov)
    #mcmc$covariance[,,1] = update_cov(Ncov, Npat, cov, mcmc$theta[,1])
    covariance = update_cov(Ncov, Npat, cov, theta)
	  inv_covariance = solve(covariance)



for (iter in 2:Niter)
{
  if (iter%%100==0) print(iter)
  tmp = update_r(mcmc$sigma2[iter-1], mcmc$muh[,,iter-1],mcmc$wh[,iter-1], mcmc$betah[,,iter-1],Npat, censor_status, response, mcmc$r[,iter-1], covariance,cov)
  mcmc$r[,iter] = tmp$r
  mcmc$imputey[,iter] = tmp$impute_y
  mcmc$muh[,,iter] = update_muh(mcmc$wh[,iter-1],mcmc$r[,iter], mcmc$sigma2[iter-1], mcmc$imputey[,iter], Npat, covariance, cov, mcmc$betah[,,iter-1], inv_covariance)
  mcmc$betah[,,iter] = update_betah(Ncov, mcmc$muh[,,iter], cov, covariance, mcmc$r[,iter], inv_covariance)
  mcmc$wh[,iter] = update_wh(mcmc$r[,iter], mcmc$M[iter-1])
	mcmc$sigma2[iter] = update_sigma2(mcmc$r[,iter], mcmc$imputey[,iter], mcmc$muh[,,iter], Npat)
	mcmc$M[iter] = update_M(mcmc$M[iter-1], Npat)
    #mcmc$theta[,iter] = nlm(L,mcmc$theta[,iter-1],muh=mcmc$muh[,,iter], Npat, cov, r=mcmc$r[,iter], Ncov)$estimate
    #mcmc$covariance[,,iter] = update_cov(Ncov, Npat, cov, mcmc$theta[,iter])
}
  return(mcmc)
}
