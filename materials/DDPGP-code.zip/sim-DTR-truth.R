Lbased_truth <- function(Induc, B1, B2)
{
  index_Z = rep(0, Npat)
  index_Z[id_R] = 1
  index_Z[id_C] = 0
  covX <- cbind(index_Z, baseline_cov_scale, front_ass)
  id1 = which(covX[,3]==Induc)
  fit = glm(index_Z~V2+front_ass,data=data.frame(covX[id1,]), family=binomial("logit"))
  dses <- data.frame(V2=baseline_cov_scale, front_ass=covX[,3])
  pr=predict(fit, newdata = dses, type="response")
  
  covX <- cbind(rep(1,Npat), baseline_cov, rep(Induc, Npat))
  
  lk1 = length(id_R)
  lk2 = length(id_C)
  covXRD = array(0, c(lk1, 5, Npat))
  covXCP = array(0, c(lk2, 4, Npat))
  for (k in 1:Npat)
  {
    covXCP[,,k] = cbind(matrix(rep(covX[k,], lk2),lk2, 3, byrow=T), log(TC))
    covXRD[,,k] = cbind(matrix(rep(covX[k,], lk1),lk1, 3, byrow=T), log(TR),rep(B1,lk1))
  }
  
  lk3 = length(TCP)
  covXPD = array(0, c(lk3, 6,lk2, Npat))
  for (k1 in 1:Npat)
  {
    for (k2 in 1:lk2)
    {
      covXPD[,,k2,k1] = cbind(matrix(rep(covX[k1,], lk3),lk3, 3, byrow=T), log(TC)[k2],log(TCP),B2)
    }
  }
  
  mcr = matrix(0, Npat, lk1)
  mcrCP = matrix(0, Npat, lk2)
  mcrPD = array(0, c(Npat, lk2))
  
  mosR = sum(pr*exp(covX%*%beta_R+1/2*0.3^2))
  mosC = sum((1-pr)*exp(covX%*%beta_C+1/2*0.3^2))
  mosR = mosR/Npat
  mosC = mosC/Npat
    for (k in 1:Npat)
    {
      mcr[k,] = exp((covXRD[,,k]%*%beta_RD+1/2*0.3^2))/lk1
      
      mcrCP[k,] = exp((covXCP[,,k]%*%beta_CP+1/2*0.3^2))/lk2
      
      for (k2 in 1:lk2)
      {
        mcrPD[k,k2] = sum(exp(covXPD[,,k2,k]%*%beta_CPD+1/2*0.3^2)/lk3  )
      }
      
    }
    mosRD = sum(pr*rowSums(mcr))/Npat
    mosCP = sum((1-pr)*rowSums(mcrCP))/Npat
    mosPD = sum((1-pr)*rowSums(mcrPD)/lk2)/Npat
    result = sum(c(mosR,mosC,mosRD,mosCP,mosPD))
  return(result)
}