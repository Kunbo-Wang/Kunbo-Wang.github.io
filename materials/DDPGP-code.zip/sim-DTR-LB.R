Lbased <- function(Induc, B1, B2)
{
  index_Z = rep(0, Npat)
  index_Z[id_R] = 1
  index_Z[id_C] = 0
  covX <- cbind(index_Z, baseline_cov_scale, front_ass)
  id1 = which(covX[,3]==Induc)
  fit = glm(index_Z~V2+front_ass,data=data.frame(covX[id1,]), family=binomial("logit"))
  covX[,3]=rep(Induc,Npat)
  dses <- data.frame(V2=baseline_cov_scale, front_ass=covX[,3])
  pr=predict(fit, newdata = dses, type="response")
  covX <- cbind(rep(1,Npat), baseline_cov_scale, rep(Induc, Npat))
  
  mosC = rep(0, 300)
  mosR = rep(0, 300)
  mosRD = rep(0, 300)
  mosCP = rep(0, 300)
  mosPD = rep(0,300)
  

  lk1 = length(id_R)
  lk2 = length(id_C)
  covXRD = array(0, c(lk1, 5, Npat))
  covXCP = array(0, c(lk2, 4, Npat))
  for (k in 1:Npat)
  {
    covXCP[,,k] = cbind(matrix(rep(covX[k,], lk2),lk2, 3, byrow=T), log(TC))
    covXRD[,,k] = cbind(matrix(rep(covX[k,], lk1),lk1, 3, byrow=T), log(TR),rep(B1,lk1))
  }

  lk3 = length(TCP)
  covXPD = array(0, c(lk3, 6,lk2, Npat))
  for (k1 in 1:Npat)
  {
    for (k2 in 1:lk2)
    {
      covXPD[,,k2,k1] = cbind(matrix(rep(covX[k1,], lk3),lk3, 3, byrow=T), log(TC)[k2],log(TCP),B2)
    }
  }
  theta = rep(1, dim(cov_frontline)[2])
  covariance_RC = update_cov(dim(cov_frontline)[2], Npat, cov_frontline_scale, theta)
  inv_covariance_RC = solve(covariance_RC)
  cR = matrix(0, Npat, dim(inv_covariance_RC)[1])
  cC = matrix(0, Npat, dim(inv_covariance_RC)[1])
  for (i in 1:Npat)
  {
    coeff = t(cov_frontline_scale)-covX[i,]
    cR[i,] = exp(-colSums(coeff^2*theta^2))
    coeff = t(cov_frontline_scale)-covX[i,]
    cC[i,] = exp(-colSums(coeff^2*theta^2))
  }
  
  thetaRD = rep(1,dim(cov_RD_scale)[2])
  covariance_RD = update_cov(dim(cov_RD_scale)[2], NRD, cov_RD_scale, thetaRD)
  inv_covariance_RD = solve(covariance_RD)
  
  thetaCP = rep(1,dim(cov_CP_scale)[2])
  covariance_CP = update_cov(dim(cov_CP_scale)[2], NC, cov_CP_scale, thetaCP)
  inv_covariance_CP = solve(covariance_CP)
  
  thetaPD = rep(1,dim(cov_CPD_scale)[2])
  covariance_PD = update_cov(dim(cov_CPD_scale)[2], NCPD, cov_CPD_scale, thetaPD)
  inv_covariance_PD = solve(covariance_PD)
  
  cRD = array(0, c(lk1, dim(inv_covariance_RD)[1], Npat))
  cCP = array(0, c(lk2, dim(inv_covariance_CP)[1], Npat))
  cPD = array(0, c(lk3, dim(inv_covariance_PD)[1], lk2, Npat))
  for (k in 1:Npat)
  {
    for (k1 in 1:lk1)
    {
      coeff = t(cov_RD_scale) - covXRD[k1,,k]
      cRD[k1,,k] = exp(-colSums(coeff^2*thetaRD^2))
    }
    for (k2 in 1:lk2)
    {
      coeff = t(cov_CP_scale) - covXCP[k2,,k]
      cCP[k2,,k] = exp(-colSums(coeff^2*thetaCP^2))
      for (k3 in 1:lk3)
      {
        coeff = t(cov_CPD_scale) - covXPD[k3,,k2,k]
        cPD[k3,,k2,k] = exp(-colSums(coeff^2*thetaPD^2))
      }
    }
  }
  mcr = matrix(0, Npat, lk1)
  mcrCP = matrix(0, Npat, lk2)
  mcrPD = array(0, c(Npat, lk2))
  
  result <- foreach (i=1:300, .combine='rbind')%dopar%
{
  print(i)
  iter = burn.in + lag*i
  mosR[i] = sum(pr*exp((covX%*%t(mcmc_R$betah[,,iter])+cR%*%inv_covariance_RC%*%t(mcmc_R$muh[,,iter]-mcmc_R$betah[,,iter]%*%t(cov_frontline_scale)))%*%mcmc_R$wh[,iter]+sum(1/2*mcmc_R$wh[,iter]^2*mcmc_R$sigma2[iter])))
  mosC[i] = sum((1-pr)*exp((covX%*%t(mcmc_C$betah[,,iter])+cC%*%inv_covariance_RC%*%t(mcmc_C$muh[,,iter]-mcmc_C$betah[,,iter]%*%t(cov_frontline_scale)))%*%mcmc_C$wh[,iter]+sum(1/2*mcmc_C$wh[,iter]^2*mcmc_C$sigma2[iter])))
  mosR[i] = mosR[i]/Npat
  mosC[i] = mosC[i]/Npat
  for (k in 1:Npat)
  {
    mcr[k,] = exp((covXRD[,,k]%*%t(mcmc_RD$betah[,,iter])+cRD[,,k]%*%inv_covariance_RD%*%t(mcmc_RD$muh[,,iter]-mcmc_RD$betah[,,iter]%*%t(cov_RD_scale)))%*%mcmc_RD$wh[,iter]+sum(1/2*mcmc_RD$wh[,iter]^2*mcmc_RD$sigma2[iter]))/lk1
    
    mcrCP[k,] = exp((covXCP[,,k]%*%t(mcmc_CP$betah[,,iter])+cCP[,,k]%*%inv_covariance_CP%*%t(mcmc_CP$muh[,,iter]-mcmc_CP$betah[,,iter]%*%t(cov_CP_scale)))%*%mcmc_CP$wh[,iter]+sum(1/2*mcmc_CP$wh[,iter]^2*mcmc_CP$sigma2[iter]))/lk2
    
    for (k2 in 1:lk2)
    {
      mcrPD[k,k2] = sum(exp((covXPD[,,k2,k]%*%t(mcmc_CPD$betah[,,iter])+cPD[,,k2,k]%*%inv_covariance_PD%*%t(mcmc_CPD$muh[,,iter]-mcmc_CPD$betah[,,iter]%*%t(cov_CPD_scale)))%*%mcmc_CPD$wh[,iter]+sum(1/2*mcmc_CPD$wh[,iter]^2*mcmc_CPD$sigma2[iter]))/lk3  )
    }
    
  }
  mosRD[i] = sum(pr*rowSums(mcr))/Npat
  mosCP[i] = sum((1-pr)*rowSums(mcrCP))/Npat
  mosPD[i] = sum((1-pr)*rowSums(mcrPD)/lk2)/Npat
  c(mosR[i],mosC[i],mosRD[i],mosCP[i],mosPD[i])
}
result1 = sum(result)/300
return(result1)
}




Lbased2 <- function(Induc, B1, B2)
{
  index_Z = rep(0, Npat)
  index_Z[id_R0] = 1
  index_Z[id_C0] = 0
  covX <- cbind(index_Z, baseline_cov_scale0, front_ass0)
  id1 = which(covX[,3]==Induc)
  fit = glm(index_Z~V2+front_ass0,data=data.frame(covX[id1,]), family=binomial("logit"))
  covX[,3]=rep(Induc,Npat)
  dses <- data.frame(V2=baseline_cov_scale0, front_ass=covX[,3])
  pr=predict(fit, newdata = dses, type="response")
  covX <- cbind(rep(1,Npat), baseline_cov_scale0, rep(Induc, Npat))
  
  mosC = rep(0, 300)
  mosR = rep(0, 300)
  mosRD = rep(0, 300)
  mosCP = rep(0, 300)
  mosPD = rep(0,300)
  
  
  lk1 = length(id_R0)
  lk2 = length(id_C0)
  covXRD = array(0, c(lk1, 5, Npat))
  covXCP = array(0, c(lk2, 4, Npat))
  for (k in 1:Npat)
  {
    covXCP[,,k] = cbind(matrix(rep(covX[k,], lk2),lk2, 3, byrow=T), log(TC0))
    covXRD[,,k] = cbind(matrix(rep(covX[k,], lk1),lk1, 3, byrow=T), log(TR0),rep(B1,lk1))
  }
  
  lk3 = length(TCP0)
  covXPD = array(0, c(lk3, 6,lk2, Npat))
  for (k1 in 1:Npat)
  {
    for (k2 in 1:lk2)
    {
      covXPD[,,k2,k1] = cbind(matrix(rep(covX[k1,], lk3),lk3, 3, byrow=T), log(TC0)[k2],log(TCP0),B2)
    }
  }
  theta = rep(1, dim(cov_frontline)[2])
  covariance_RC = update_cov(dim(cov_frontline)[2], Npat, cov_frontline_scale, theta)
  inv_covariance_RC = solve(covariance_RC)
  cR = matrix(0, Npat, dim(inv_covariance_RC)[1])
  cC = matrix(0, Npat, dim(inv_covariance_RC)[1])
  for (i in 1:Npat)
  {
    coeff = t(cov_frontline_scale)-covX[i,]
    cR[i,] = exp(-colSums(coeff^2*theta^2))
    coeff = t(cov_frontline_scale)-covX[i,]
    cC[i,] = exp(-colSums(coeff^2*theta^2))
  }
  
  thetaRD = rep(1,dim(cov_RD_scale)[2])
  covariance_RD = update_cov(dim(cov_RD_scale)[2], NRD, cov_RD_scale, thetaRD)
  inv_covariance_RD = solve(covariance_RD)
  
  thetaCP = rep(1,dim(cov_CP_scale)[2])
  covariance_CP = update_cov(dim(cov_CP_scale)[2], NC, cov_CP_scale, thetaCP)
  inv_covariance_CP = solve(covariance_CP)
  
  thetaPD = rep(1,dim(cov_CPD_scale)[2])
  covariance_PD = update_cov(dim(cov_CPD_scale)[2], NCPD, cov_CPD_scale, thetaPD)
  inv_covariance_PD = solve(covariance_PD)
  
  cRD = array(0, c(lk1, dim(inv_covariance_RD)[1], Npat))
  cCP = array(0, c(lk2, dim(inv_covariance_CP)[1], Npat))
  cPD = array(0, c(lk3, dim(inv_covariance_PD)[1], lk2, Npat))
  for (k in 1:Npat)
  {
    for (k1 in 1:lk1)
    {
      coeff = t(cov_RD_scale) - covXRD[k1,,k]
      cRD[k1,,k] = exp(-colSums(coeff^2*thetaRD^2))
    }
    for (k2 in 1:lk2)
    {
      coeff = t(cov_CP_scale) - covXCP[k2,,k]
      cCP[k2,,k] = exp(-colSums(coeff^2*thetaCP^2))
      for (k3 in 1:lk3)
      {
        coeff = t(cov_CPD_scale) - covXPD[k3,,k2,k]
        cPD[k3,,k2,k] = exp(-colSums(coeff^2*thetaPD^2))
      }
    }
  }
  mcr = matrix(0, Npat, lk1)
  mcrCP = matrix(0, Npat, lk2)
  mcrPD = array(0, c(Npat, lk2))
  
  result <- foreach (i=1:300, .combine='rbind')%dopar%
{
  print(i)
  iter = burn.in + lag*i
  mosR[i] = sum(pr*exp((covX%*%t(mcmc_R$betah[,,iter])+cR%*%inv_covariance_RC%*%t(mcmc_R$muh[,,iter]-mcmc_R$betah[,,iter]%*%t(cov_frontline_scale)))%*%mcmc_R$wh[,iter]+sum(1/2*mcmc_R$wh[,iter]^2*mcmc_R$sigma2[iter])))
  mosC[i] = sum((1-pr)*exp((covX%*%t(mcmc_C$betah[,,iter])+cC%*%inv_covariance_RC%*%t(mcmc_C$muh[,,iter]-mcmc_C$betah[,,iter]%*%t(cov_frontline_scale)))%*%mcmc_C$wh[,iter]+sum(1/2*mcmc_C$wh[,iter]^2*mcmc_C$sigma2[iter])))
  mosR[i] = mosR[i]/Npat
  mosC[i] = mosC[i]/Npat
  for (k in 1:Npat)
  {
    mcr[k,] = exp((covXRD[,,k]%*%t(mcmc_RD$betah[,,iter])+cRD[,,k]%*%inv_covariance_RD%*%t(mcmc_RD$muh[,,iter]-mcmc_RD$betah[,,iter]%*%t(cov_RD_scale)))%*%mcmc_RD$wh[,iter]+sum(1/2*mcmc_RD$wh[,iter]^2*mcmc_RD$sigma2[iter]))/lk1
    
    mcrCP[k,] = exp((covXCP[,,k]%*%t(mcmc_CP$betah[,,iter])+cCP[,,k]%*%inv_covariance_CP%*%t(mcmc_CP$muh[,,iter]-mcmc_CP$betah[,,iter]%*%t(cov_CP_scale)))%*%mcmc_CP$wh[,iter]+sum(1/2*mcmc_CP$wh[,iter]^2*mcmc_CP$sigma2[iter]))/lk2
    
    for (k2 in 1:lk2)
    {
      mcrPD[k,k2] = sum(exp((covXPD[,,k2,k]%*%t(mcmc_CPD$betah[,,iter])+cPD[,,k2,k]%*%inv_covariance_PD%*%t(mcmc_CPD$muh[,,iter]-mcmc_CPD$betah[,,iter]%*%t(cov_CPD_scale)))%*%mcmc_CPD$wh[,iter]+sum(1/2*mcmc_CPD$wh[,iter]^2*mcmc_CPD$sigma2[iter]))/lk3  )
    }
    
  }
  mosRD[i] = sum(pr*rowSums(mcr))/Npat
  mosCP[i] = sum((1-pr)*rowSums(mcrCP))/Npat
  mosPD[i] = sum((1-pr)*rowSums(mcrPD)/lk2)/Npat
  c(mosR[i],mosC[i],mosRD[i],mosCP[i],mosPD[i])
}
result1 = sum(result)/300
return(result1)
}

