IPTW <- function(A, B1, B2)
{
  w = rep(0, Npat)
  #get the K
  K = rep(0, Npat)
  status = rep(1, Npat)
  status[id_censor] = 0
  lfit = survfit(Surv(T0, status)~1)
  for (i in 1:Npat)
  {
    K[i] = lfit$surv[which(round(lfit$time,4)==round(T0[i],4))]
  }
  id0 = which(K==0)
  
  cons = (front_ass==A)*(status)/K
  cons[id0] = 0
  
  # for I(Z_1i=1)
  cov1 = matrix(c(baseline_cov_scale[id_R], front_ass[id_R], log(TR), salvage_R), NRD, 4)
  fit_RD = glm(cov1[,4]~cov1[,1] + cov1[,2] +cov1[,3], family=binomial("logit"))
  fitRD1 = fitted(fit_RD)
  w[id_R] = cons[id_R]*(cov1[,4]==B1)/(B1*fitRD1+(1-B1)*(1-fitRD1))
  
  # for I(Z_1i=2, Z_2i=1)
  cov2 = matrix(c(baseline_cov_scale[id_CPD], front_ass[id_CPD], log(TC[-id_censor_CP]),log(TCP[-id_censor_CP]), salvage_CPD), NCPD, 5)
  fit_CP = glm(cov2[,5]~cov2[,1] + cov2[,2] +cov2[,3] + cov2[,4], family=binomial("logit"))
  fitCP1 = fitted(fit_CP)
  w[id_CPD] = cons[id_CPD]*(cov2[,5]==B2)/(B2*fitCP1+(1-B2)*(1-fitCP1))
  
  IPTW = sum(w*T0)/sum(w)
  return(IPTW)
}


